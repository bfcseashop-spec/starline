#!/bin/bash
# Skyline Properties Hub – deploy with backup (same pattern as primepos)
# Usage: ./deploy.sh [--no-deploy]

set -e
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

BACKUP_DIR="${BACKUP_DIR:-$SCRIPT_DIR/backups}"
mkdir -p "$BACKUP_DIR"
TIMESTAMP=$(date +%m-%d-%Y-%H-%M)
PREFIX="${TIMESTAMP}-skyline"
TAR_FILE="$BACKUP_DIR/${PREFIX}.tar.gz"
SQL_FILE="$BACKUP_DIR/${PREFIX}.sql"

echo "=== Skyline Properties Hub – Backup & Deploy ==="
echo "Timestamp: $TIMESTAMP"
echo "Backup dir: $BACKUP_DIR"
echo ""

if [ -f .env ]; then
  set -a
  source .env 2>/dev/null || true
  set +a
fi

echo "[1/7] Backing up code to $TAR_FILE"
tar --exclude='node_modules' --exclude='dist' --exclude='.git' --exclude='backups' \
  --exclude='*.zip' --exclude='*.tar.gz' --exclude='*.sql' --exclude='.env' \
  -czf "$TAR_FILE" .
echo "  Code backup: $TAR_FILE"

if [ -n "$DATABASE_URL" ]; then
  echo "[2/7] Backing up database to $SQL_FILE"
  if command -v pg_dump >/dev/null 2>&1; then
    if pg_dump "$DATABASE_URL" -F p -f "$SQL_FILE" 2>"$BACKUP_DIR/.pg_dump_err"; then
      echo "  Database backup: $SQL_FILE"
      rm -f "$BACKUP_DIR/.pg_dump_err"
    else
      echo "  WARNING: pg_dump failed. Skipping DB backup."
      [ -s "$BACKUP_DIR/.pg_dump_err" ] && cat "$BACKUP_DIR/.pg_dump_err"
      rm -f "$SQL_FILE" "$BACKUP_DIR/.pg_dump_err"
    fi
  else
    echo "  WARNING: pg_dump not found. Skipping DB backup."
  fi
else
  echo "[2/7] Skipping DB backup (DATABASE_URL not set)"
fi

if [ "$1" = "--no-deploy" ]; then
  echo ""
  echo "Backup complete. (--no-deploy: skipping deployment)"
  exit 0
fi

echo ""
echo "[3/7] git pull"
git pull

echo "[4/7] npm install"
npm install

echo "[5/7] npm run build"
npm run build

echo "[6/7] npm run db:push"
npx drizzle-kit push --force

echo "[7/7] pm2 restart"
npm run pm2:restart

echo ""
echo "=== Deploy complete ==="
echo "Backups: $TAR_FILE, $SQL_FILE"
