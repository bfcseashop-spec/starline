
-- Site settings table (key-value store for all admin-controlled settings)
CREATE TABLE IF NOT EXISTS public.site_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  key text NOT NULL UNIQUE,
  value text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.site_settings ENABLE ROW LEVEL SECURITY;

-- Only admins can manage settings; public can read them for frontend rendering
CREATE POLICY "Admins can manage settings"
  ON public.site_settings
  FOR ALL
  TO authenticated
  USING (has_role(auth.uid(), 'admin'::app_role))
  WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Anyone can read settings"
  ON public.site_settings
  FOR SELECT
  USING (true);

-- Navbar links table
CREATE TABLE IF NOT EXISTS public.navbar_links (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  label text NOT NULL,
  href text NOT NULL,
  display_order integer NOT NULL DEFAULT 0,
  is_visible boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.navbar_links ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins can manage navbar links"
  ON public.navbar_links
  FOR ALL
  TO authenticated
  USING (has_role(auth.uid(), 'admin'::app_role))
  WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Anyone can read navbar links"
  ON public.navbar_links
  FOR SELECT
  USING (true);

-- Social media integrations table
CREATE TABLE IF NOT EXISTS public.social_integrations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  platform text NOT NULL UNIQUE,
  url text,
  is_enabled boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.social_integrations ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins can manage social integrations"
  ON public.social_integrations
  FOR ALL
  TO authenticated
  USING (has_role(auth.uid(), 'admin'::app_role))
  WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Anyone can read social integrations"
  ON public.social_integrations
  FOR SELECT
  USING (true);

-- Auto-update timestamps
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END;
$$ LANGUAGE plpgsql SET search_path = public;

CREATE TRIGGER update_site_settings_updated_at
  BEFORE UPDATE ON public.site_settings
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_navbar_links_updated_at
  BEFORE UPDATE ON public.navbar_links
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_social_integrations_updated_at
  BEFORE UPDATE ON public.social_integrations
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Seed default navbar links
INSERT INTO public.navbar_links (label, href, display_order, is_visible) VALUES
  ('Home', '/', 1, true),
  ('Properties', '/properties', 2, true),
  ('Contact', '/contact', 3, true)
ON CONFLICT DO NOTHING;

-- Seed default social platforms (all disabled until admin adds URLs)
INSERT INTO public.social_integrations (platform, url, is_enabled) VALUES
  ('youtube', '', false),
  ('facebook', '', false),
  ('instagram', '', false),
  ('tiktok', '', false),
  ('twitter', '', false),
  ('linkedin', '', false),
  ('whatsapp', '', false)
ON CONFLICT (platform) DO NOTHING;

-- Seed default site settings
INSERT INTO public.site_settings (key, value) VALUES
  ('currency', 'BDT'),
  ('currency_symbol', '৳'),
  ('phone_bd', '+880 170 000 0000'),
  ('phone_dubai', '+971 4 000 0000'),
  ('email', 'info@skylineholding.com'),
  ('address_bd', 'Gulshan 2, Dhaka 1212, Bangladesh'),
  ('address_dubai', 'Downtown Dubai, UAE'),
  ('site_title', 'Skyline Holding Ltd'),
  ('site_tagline', 'Premium Real Estate in Bangladesh & Dubai')
ON CONFLICT (key) DO NOTHING;
