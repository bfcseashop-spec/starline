
-- Add installment payment fields to properties table
ALTER TABLE public.properties
  ADD COLUMN IF NOT EXISTS is_installment boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS down_payment_pct numeric NOT NULL DEFAULT 20,
  ADD COLUMN IF NOT EXISTS installment_years integer NOT NULL DEFAULT 5;
