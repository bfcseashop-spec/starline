const API = ""; // same origin (Vite proxy in dev, same server in prod)

function fetchApi(path: string, options: RequestInit = {}) {
  return fetch(`${API}${path}`, {
    ...options,
    credentials: "include",
    headers: {
      "Content-Type": "application/json",
      ...options.headers,
    },
  });
}

async function handleRes<T>(res: Response): Promise<T> {
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error((data as { message?: string }).message || res.statusText);
  return data as T;
}

// Auth
export async function getSession() {
  const res = await fetchApi("/api/auth/me");
  if (res.status === 401) return null;
  return handleRes<{ id: string; email: string; full_name: string | null; isAdmin: boolean }>(res);
}

export async function login(email: string, password: string, adminOnly?: boolean) {
  const res = await fetchApi("/api/auth/login", {
    method: "POST",
    body: JSON.stringify({ email, password, adminOnly }),
  });
  return handleRes<{ user: { id: string; email: string; full_name: string | null; isAdmin: boolean } }>(res);
}

export async function logout() {
  await fetchApi("/api/auth/logout", { method: "POST" });
}

export async function signup(email: string, password: string, fullName?: string) {
  const res = await fetchApi("/api/auth/signup", {
    method: "POST",
    body: JSON.stringify({ email, password, full_name: fullName }),
  });
  return handleRes<{ user: { id: string; email: string; full_name: string | null; isAdmin: boolean } }>(res);
}

// Public – Properties
export async function getProperties(filters: Record<string, string>) {
  const params = new URLSearchParams(filters);
  const res = await fetch(`${API}/api/properties?${params}`, { credentials: "include" });
  return handleRes<any[]>(res);
}

export async function getProperty(id: string) {
  const res = await fetch(`${API}/api/properties/${id}`, { credentials: "include" });
  if (res.status === 404) return null;
  return handleRes<any>(res);
}

export async function getPropertyMedia(propertyId: string) {
  const res = await fetch(`${API}/api/properties/${propertyId}/media`, { credentials: "include" });
  return handleRes<any[]>(res);
}

export async function getFeaturedProperties() {
  const res = await fetch(`${API}/api/properties/featured`, { credentials: "include" });
  return handleRes<any[]>(res);
}

export async function getPropertyStats() {
  const res = await fetch(`${API}/api/properties/stats`, { credentials: "include" });
  return handleRes<{ total: number; forSale: number; forRent: number }>(res);
}

// Public – Contact
export async function submitContactInquiry(body: {
  property_id?: string | null;
  name: string;
  email: string;
  phone?: string;
  message: string;
}) {
  const res = await fetchApi("/api/contact-inquiries", {
    method: "POST",
    body: JSON.stringify(body),
  });
  return handleRes<{ message: string }>(res);
}

// Public – Settings / Nav / Social
export async function getSiteSettings() {
  const res = await fetch(`${API}/api/site-settings`, { credentials: "include" });
  return handleRes<any[]>(res);
}

export async function getNavbarLinks() {
  const res = await fetch(`${API}/api/navbar-links`, { credentials: "include" });
  return handleRes<any[]>(res);
}

export async function getSocialIntegrations() {
  const res = await fetch(`${API}/api/social-integrations`, { credentials: "include" });
  return handleRes<any[]>(res);
}

export async function getWhatsApp() {
  const res = await fetch(`${API}/api/social-integrations/whatsapp`, { credentials: "include" });
  if (res.status === 404) return null;
  return handleRes<{ url: string | null; is_enabled: boolean } | null>(res);
}

// Admin – Properties
export async function getAdminProperties() {
  const res = await fetchApi("/api/admin/properties");
  return handleRes<any[]>(res);
}

export async function createProperty(body: any) {
  const res = await fetchApi("/api/admin/properties", {
    method: "POST",
    body: JSON.stringify(body),
  });
  return handleRes<any>(res);
}

export async function updateProperty(id: string, body: any) {
  const res = await fetchApi(`/api/admin/properties/${id}`, {
    method: "PATCH",
    body: JSON.stringify(body),
  });
  return handleRes<any>(res);
}

export async function deleteProperty(id: string) {
  const res = await fetchApi(`/api/admin/properties/${id}`, { method: "DELETE" });
  if (res.status !== 204) await handleRes(res);
}

export async function uploadPropertyMedia(propertyId: string, file: File) {
  const form = new FormData();
  form.append("file", file);
  const res = await fetch(`${API}/api/admin/properties/${propertyId}/media`, {
    method: "POST",
    credentials: "include",
    body: form,
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error((data as { message?: string }).message || "Upload failed");
  return data as any;
}

export async function deletePropertyMedia(mediaId: string) {
  const res = await fetchApi(`/api/admin/property-media/${mediaId}`, { method: "DELETE" });
  if (res.status !== 204) await handleRes(res);
}

export async function setPropertyFeatured(id: string) {
  const res = await fetchApi(`/api/admin/properties/${id}/featured`, { method: "PATCH" });
  return handleRes<any>(res);
}

export async function setPropertyCover(propertyId: string, url: string) {
  const res = await fetchApi(`/api/admin/properties/${propertyId}/cover`, {
    method: "PATCH",
    body: JSON.stringify({ url }),
  });
  return handleRes<any>(res);
}

// Admin – Inquiries
export async function getAdminContactInquiries() {
  const res = await fetchApi("/api/admin/contact-inquiries");
  return handleRes<any[]>(res);
}

export async function markInquiryRead(id: string) {
  const res = await fetchApi(`/api/admin/contact-inquiries/${id}/read`, { method: "PATCH" });
  return handleRes(res);
}

// Admin – Site settings
export async function upsertSiteSetting(key: string, value: string) {
  const res = await fetchApi("/api/admin/site-settings/upsert", {
    method: "POST",
    body: JSON.stringify({ key, value }),
  });
  return handleRes<any>(res);
}

// Admin – Navbar
export async function getAdminNavbarLinks() {
  const res = await fetchApi("/api/admin/navbar-links");
  return handleRes<any[]>(res);
}

export async function createNavbarLink(body: { label: string; href: string }) {
  const res = await fetchApi("/api/admin/navbar-links", {
    method: "POST",
    body: JSON.stringify(body),
  });
  return handleRes<any>(res);
}

export async function updateNavbarLink(id: string, body: { label?: string; href?: string; display_order?: number; is_visible?: boolean }) {
  const res = await fetchApi(`/api/admin/navbar-links/${id}`, {
    method: "PATCH",
    body: JSON.stringify(body),
  });
  return handleRes<any>(res);
}

export async function deleteNavbarLink(id: string) {
  const res = await fetchApi(`/api/admin/navbar-links/${id}`, { method: "DELETE" });
  if (res.status !== 204) await handleRes(res);
}

export async function reorderNavbarLinks(aId: string, bId: string) {
  const res = await fetchApi("/api/admin/navbar-links/reorder", {
    method: "POST",
    body: JSON.stringify({ aId, bId }),
  });
  return handleRes(res);
}

// Admin – Social
export async function getAdminSocialIntegrations() {
  const res = await fetchApi("/api/admin/social-integrations");
  return handleRes<any[]>(res);
}

export async function upsertSocialIntegration(body: { platform: string; url?: string; is_enabled?: boolean }) {
  const res = await fetchApi("/api/admin/social-integrations", {
    method: "PUT",
    body: JSON.stringify(body),
  });
  return handleRes<any>(res);
}
