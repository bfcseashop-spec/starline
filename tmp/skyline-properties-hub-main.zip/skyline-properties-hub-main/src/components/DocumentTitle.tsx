import { useEffect } from "react";
import { useSiteSettings } from "@/hooks/use-site-settings";

const DEFAULT_TITLE = "Skyline Holding Ltd | Premium Real Estate Bangladesh & Dubai";

const DocumentTitle = () => {
  const { settings, isLoading } = useSiteSettings();

  useEffect(() => {
    if (isLoading) return;
    const entry = settings.find((s) => s.key === "site_title");
    const siteTitle = entry?.value?.trim() || "Skyline Holding Ltd";
    document.title = `${siteTitle} | Premium Real Estate Bangladesh & Dubai`;
  }, [settings, isLoading]);

  return null;
};

export default DocumentTitle;
