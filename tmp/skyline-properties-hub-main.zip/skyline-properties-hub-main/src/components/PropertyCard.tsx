import { Link } from "react-router-dom";
import { MapPin, Bed, Bath, Maximize, Heart, Tag } from "lucide-react";

interface Property {
  id: string;
  title: string;
  address: string;
  city: string;
  country: string;
  price: number;
  price_type: string;
  property_type: string;
  bedrooms: number | null;
  bathrooms: number | null;
  area_sqft: number | null;
  cover_image_url: string | null;
  status: string;
  is_featured: boolean;
}

interface PropertyCardProps {
  property: Property;
}

const formatPrice = (price: number, country: string) => {
  if (country === "UAE") {
    return `AED ${price.toLocaleString()}`;
  }
  return `BDT ${price.toLocaleString()}`;
};

const PropertyCard = ({ property }: PropertyCardProps) => {
  return (
    <Link to={`/properties/${property.id}`} className="group block">
      <div className="bg-card rounded-xl overflow-hidden shadow-card hover:shadow-lg transition-all duration-300 hover:-translate-y-1">
        {/* Image */}
        <div className="relative aspect-[4/3] overflow-hidden">
          {property.cover_image_url ? (
            <img
              src={property.cover_image_url}
              alt={property.title}
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
            />
          ) : (
            <div className="w-full h-full bg-gradient-to-br from-primary/20 to-primary/5 flex items-center justify-center">
              <div className="text-muted-foreground text-center">
                <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center mx-auto mb-2">
                  <MapPin className="w-7 h-7 text-muted-foreground" />
                </div>
                <span className="text-sm">No Image</span>
              </div>
            </div>
          )}

          {/* Badges */}
          <div className="absolute top-3 left-3 flex gap-2">
            <span className={`px-2.5 py-1 rounded font-body text-xs font-semibold uppercase tracking-wide ${
              property.price_type === 'sale'
                ? 'bg-primary text-primary-foreground'
                : 'bg-gold text-primary'
            }`}>
              {property.price_type === 'sale' ? 'For Sale' : 'For Rent'}
            </span>
            {property.is_featured && (
              <span className="px-2.5 py-1 rounded font-body text-xs font-semibold uppercase tracking-wide bg-gold text-primary">
                Featured
              </span>
            )}
          </div>

          {/* Status overlay if sold/rented */}
          {property.status !== 'available' && (
            <div className="absolute inset-0 bg-primary/60 flex items-center justify-center">
              <span className="px-4 py-2 bg-destructive text-destructive-foreground font-display font-semibold text-sm rounded uppercase tracking-widest">
                {property.status}
              </span>
            </div>
          )}
        </div>

        {/* Info */}
        <div className="p-5">
          <div className="flex items-start justify-between gap-2 mb-2">
            <h3 className="font-display font-semibold text-card-foreground text-lg leading-tight group-hover:text-gold transition-colors line-clamp-2">
              {property.title}
            </h3>
          </div>

          <div className="flex items-center gap-1.5 text-muted-foreground mb-4">
            <MapPin className="w-3.5 h-3.5 text-gold shrink-0" />
            <span className="font-body text-sm truncate">
              {property.city}, {property.country}
            </span>
          </div>

          {/* Stats */}
          <div className="flex items-center gap-4 text-muted-foreground mb-4">
            {property.bedrooms && (
              <div className="flex items-center gap-1.5">
                <Bed className="w-3.5 h-3.5" />
                <span className="font-body text-xs">{property.bedrooms} Bed</span>
              </div>
            )}
            {property.bathrooms && (
              <div className="flex items-center gap-1.5">
                <Bath className="w-3.5 h-3.5" />
                <span className="font-body text-xs">{property.bathrooms} Bath</span>
              </div>
            )}
            {property.area_sqft && (
              <div className="flex items-center gap-1.5">
                <Maximize className="w-3.5 h-3.5" />
                <span className="font-body text-xs">{property.area_sqft.toLocaleString()} sqft</span>
              </div>
            )}
          </div>

          {/* Price */}
          <div className="flex items-center justify-between border-t border-border pt-4">
            <div>
              <div className="font-display font-bold text-gold text-xl">
                {formatPrice(property.price, property.country)}
              </div>
              {property.price_type === 'rent' && (
                <div className="font-body text-xs text-muted-foreground">/month</div>
              )}
            </div>
            <span className="px-2.5 py-1 bg-secondary text-secondary-foreground font-body text-xs rounded capitalize">
              {property.property_type}
            </span>
          </div>
        </div>
      </div>
    </Link>
  );
};

export default PropertyCard;
