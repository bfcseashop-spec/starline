import { Link, useLocation } from "react-router-dom";
import { useState } from "react";
import { Menu, X, Phone } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { getNavbarLinks } from "@/lib/api";
import { useSiteSettings } from "@/hooks/use-site-settings";

const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);
  const location = useLocation();
  const isActive = (path: string) => location.pathname === path;
  const { getSetting } = useSiteSettings();

  const { data: navbarLinks = [] } = useQuery({
    queryKey: ["navbar-links"],
    queryFn: getNavbarLinks,
    staleTime: 30_000,
  });

  const navLinks = (navbarLinks as any[]).length > 0
    ? navbarLinks as any[]
    : [
        { id: "home", href: "/", label: "Home" },
        { id: "props", href: "/properties", label: "Properties" },
        { id: "contact", href: "/contact", label: "Contact" },
      ];

  const phone = getSetting("navbar_phone", "+880 170 000 0000");
  const showLogin = getSetting("navbar_show_login", "true") !== "false";
  const showAdmin = getSetting("navbar_show_admin", "true") !== "false";

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-primary/95 backdrop-blur-sm border-b border-gold/20 transition-smooth">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16 lg:h-20">

          {/* Logo */}
          <Link to="/" className="flex items-center gap-3 transition-transform duration-200 hover:opacity-90 active:scale-[0.98]">
            <div className="w-9 h-9 bg-gradient-gold rounded flex items-center justify-center shadow-gold transition-shadow duration-300 hover:shadow-gold">
              <span className="font-display font-bold text-primary text-sm">SH</span>
            </div>
            <div>
              <div className="font-display font-bold text-primary-foreground text-sm lg:text-base leading-tight">
                {getSetting("site_title", "Skyline Holding Ltd")}
              </div>
              <div className="text-gold text-xs font-body font-medium tracking-widest uppercase">
                {getSetting("site_tagline", "Premium Real Estate")}
              </div>
            </div>
          </Link>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center gap-8">
            {navLinks.map((link: any) => (
              <Link
                key={link.id || link.href}
                to={link.href}
                className={`font-body text-sm font-medium transition-colors duration-200 tracking-wide ${
                  isActive(link.href) ? "text-gold" : "text-primary-foreground/80 hover:text-gold"
                }`}
              >
                {link.label}
              </Link>
            ))}
          </div>

          {/* Desktop CTA */}
          <div className="hidden md:flex items-center gap-3">
            {phone && (
              <a
                href={`tel:${phone.replace(/\s/g, "")}`}
                className="flex items-center gap-2 text-primary-foreground/80 hover:text-gold transition-colors duration-200 text-sm font-body"
              >
                <Phone className="w-4 h-4" />
                <span>{phone}</span>
              </a>
            )}
            {showLogin && (
              <Link
                to="/auth?mode=customer"
                className="px-4 py-2 border border-gold/40 text-primary-foreground/80 font-body font-medium text-sm rounded hover:text-gold hover:border-gold transition-all duration-200"
              >
                Login
              </Link>
            )}
            {showAdmin && (
              <Link
                to="/auth?mode=admin"
                className="px-4 py-2 bg-gradient-gold text-primary font-body font-semibold text-sm rounded shadow-gold hover:opacity-90 hover:shadow-lg transition-all duration-200"
              >
                Admin
              </Link>
            )}
          </div>

          {/* Mobile toggle */}
          <button onClick={() => setIsOpen(!isOpen)} className="md:hidden text-primary-foreground p-2 -m-2 rounded-lg hover:bg-white/5 transition-colors duration-200" aria-label={isOpen ? "Close menu" : "Open menu"}>
            {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {/* Mobile Dropdown */}
        {isOpen && (
          <div className="md:hidden py-4 border-t border-gold/20 space-y-1 animate-slide-down">
            {navLinks.map((link: any) => (
              <Link
                key={link.id || link.href}
                to={link.href}
                onClick={() => setIsOpen(false)}
                className={`block font-body text-sm font-medium py-2.5 px-2 rounded-lg transition-colors duration-200 ${
                  isActive(link.href) ? "text-gold bg-gold/5" : "text-primary-foreground/80 hover:text-gold"
                }`}
              >
                {link.label}
              </Link>
            ))}
            {phone && (
              <a href={`tel:${phone.replace(/\s/g, "")}`} className="flex items-center gap-2 py-2.5 px-2 text-primary-foreground/70 font-body text-sm">
                <Phone className="w-4 h-4 text-gold" />{phone}
              </a>
            )}
            <div className="flex gap-2 pt-2">
              {showLogin && (
                <Link to="/auth?mode=customer" onClick={() => setIsOpen(false)} className="flex-1 text-center px-4 py-2 border border-gold/40 text-primary-foreground/80 font-body font-medium text-sm rounded hover:text-gold hover:border-gold transition-all duration-200">
                  Login
                </Link>
              )}
              {showAdmin && (
                <Link to="/auth?mode=admin" onClick={() => setIsOpen(false)} className="flex-1 text-center px-4 py-2 bg-gradient-gold text-primary font-body font-semibold text-sm rounded shadow-gold hover:opacity-90 transition-all duration-200">
                  Admin
                </Link>
              )}
            </div>
          </div>
        )}
      </div>
    </nav>
  );
};

export default Navbar;
