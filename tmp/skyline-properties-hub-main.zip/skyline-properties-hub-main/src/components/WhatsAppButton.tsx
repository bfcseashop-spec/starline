import { useQuery } from "@tanstack/react-query";
import { getWhatsApp } from "@/lib/api";

import { useState } from "react";

const WhatsAppButton = () => {
  const [hovered, setHovered] = useState(false);

  const { data: whatsapp } = useQuery({
    queryKey: ["whatsapp-integration"],
    queryFn: getWhatsApp,
  });

  if (!whatsapp?.is_enabled || !whatsapp?.url) return null;

  const rawUrl = (whatsapp.url || "").trim();
  const href = rawUrl.startsWith("http")
    ? rawUrl
    : `https://wa.me/${rawUrl.replace(/\D/g, "")}`;

  return (
    <a
      href={href}
      target="_blank"
      rel="noopener noreferrer"
      aria-label="Chat with us on WhatsApp"
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      className="fixed bottom-6 right-6 z-50 flex items-center gap-3 group"
    >
      {/* Tooltip label */}
      <span
        className={`
          font-body text-sm font-medium px-3 py-1.5 rounded-full
          bg-primary text-primary-foreground shadow-lg
          transition-all duration-300 whitespace-nowrap
          ${hovered ? "opacity-100 translate-x-0" : "opacity-0 translate-x-4 pointer-events-none"}
        `}
      >
        Chat with us
      </span>

      {/* Button */}
      <div className="relative">
        {/* Pulse ring */}
        <span className="absolute inset-0 rounded-full animate-ping bg-[hsl(142,70%,45%)] opacity-30" />

        <div
          className="relative w-14 h-14 rounded-full flex items-center justify-center shadow-lg transition-all duration-300 group-hover:scale-110 group-hover:shadow-xl"
          style={{
            background: "linear-gradient(135deg, hsl(142,70%,38%) 0%, hsl(142,60%,48%) 100%)",
            boxShadow: "0 6px 24px hsl(142,70%,38%,0.45)",
          }}
        >
          {/* WhatsApp SVG icon (official look) */}
          <svg
            xmlns="http://www.w3.org/2000/svg"
            viewBox="0 0 32 32"
            className="w-7 h-7"
            fill="white"
            aria-hidden="true"
          >
            <path d="M16.004 2.667C8.637 2.667 2.667 8.637 2.667 16c0 2.356.637 4.663 1.846 6.676L2.667 29.333l6.817-1.786A13.29 13.29 0 0 0 16.004 29.333c7.367 0 13.329-5.97 13.329-13.333 0-7.363-5.962-13.333-13.329-13.333Zm0 24.267a11.093 11.093 0 0 1-5.657-1.548l-.405-.241-4.047 1.061 1.08-3.937-.264-.413A11.053 11.053 0 0 1 4.934 16c0-6.107 4.963-11.067 11.07-11.067S27.07 9.893 27.07 16s-4.959 11.067-11.066 11.067v-.133Zm6.07-8.29c-.333-.167-1.97-.972-2.276-1.082-.307-.11-.53-.167-.753.167s-.863 1.082-1.059 1.305c-.195.222-.39.25-.723.083-.333-.167-1.407-.518-2.68-1.65-.99-.88-1.659-1.968-1.854-2.301-.196-.333-.021-.513.147-.678.151-.148.333-.39.5-.583.167-.194.222-.333.333-.556.111-.222.056-.417-.028-.583-.083-.167-.753-1.815-1.031-2.486-.272-.653-.548-.565-.753-.576l-.64-.011a1.23 1.23 0 0 0-.89.417c-.306.333-1.17 1.143-1.17 2.79s1.198 3.238 1.365 3.46c.167.222 2.357 3.598 5.713 5.047.798.345 1.421.55 1.906.704.801.255 1.53.22 2.106.133.643-.097 1.97-.807 2.249-1.585.278-.779.278-1.447.195-1.585-.083-.139-.306-.222-.64-.389Z"/>
          </svg>
        </div>
      </div>
    </a>
  );
};

export default WhatsAppButton;
