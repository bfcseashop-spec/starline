import { Link } from "react-router-dom";
import { MapPin, Mail, Phone, Facebook, Instagram, Linkedin, Youtube, Twitter, Video } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { getSocialIntegrations } from "@/lib/api";
import { useSiteSettings } from "@/hooks/use-site-settings";

const PLATFORM_ICONS: Record<string, React.ElementType> = {
  youtube:   Youtube,
  facebook:  Facebook,
  instagram: Instagram,
  tiktok:    Video,
  twitter:   Twitter,
  linkedin:  Linkedin,
  whatsapp:  Phone,
};

const Footer = () => {
  const { data: socialIntegrations = [] } = useQuery({
    queryKey: ["footer-socials"],
    queryFn: getSocialIntegrations,
  });
  const socials = (socialIntegrations as any[]).filter((s) => s.is_enabled && s.url);
  const { getSetting } = useSiteSettings();

  return (
    <footer className="bg-primary text-primary-foreground">
      <div className="container mx-auto px-4 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10">

          {/* Brand */}
          <div className="lg:col-span-2">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-10 h-10 bg-gradient-gold rounded flex items-center justify-center shadow-gold">
                <span className="font-display font-bold text-primary text-sm">SH</span>
              </div>
              <div>
                <div className="font-display font-bold text-primary-foreground text-lg leading-tight">
                  {getSetting("site_title", "Skyline Holding Ltd")}
                </div>
                <div className="text-gold text-xs font-body tracking-widest uppercase">
                  {getSetting("site_tagline", "Premium Real Estate")}
                </div>
              </div>
            </div>
            <p className="text-primary-foreground/70 font-body text-sm leading-relaxed max-w-sm">
              Your trusted partner for premium property sales and rentals across Bangladesh and Dubai.
              We bring luxury living to your doorstep.
            </p>

            {/* Dynamic social icons */}
            {socials.length > 0 && (
              <div className="flex items-center gap-3 mt-6 flex-wrap">
                {(socials as any[]).map((s) => {
                  const Icon = PLATFORM_ICONS[s.platform];
                  if (!Icon) return null;
                  return (
                    <a
                      key={s.platform}
                      href={s.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      aria-label={s.platform}
                      title={s.platform.charAt(0).toUpperCase() + s.platform.slice(1)}
                      className="w-9 h-9 rounded-full bg-primary-foreground/10 flex items-center justify-center hover:bg-gold hover:text-primary transition-all duration-200"
                    >
                      <Icon className="w-4 h-4" />
                    </a>
                  );
                })}
              </div>
            )}

            {/* Fallback static icons when nothing is configured yet */}
            {socials.length === 0 && (
              <div className="flex items-center gap-3 mt-6">
                <span className="w-9 h-9 rounded-full bg-primary-foreground/10 flex items-center justify-center opacity-30">
                  <Facebook className="w-4 h-4" />
                </span>
                <span className="w-9 h-9 rounded-full bg-primary-foreground/10 flex items-center justify-center opacity-30">
                  <Instagram className="w-4 h-4" />
                </span>
                <span className="w-9 h-9 rounded-full bg-primary-foreground/10 flex items-center justify-center opacity-30">
                  <Linkedin className="w-4 h-4" />
                </span>
              </div>
            )}
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-display font-semibold text-gold mb-5">Quick Links</h4>
            <ul className="space-y-3 font-body text-sm text-primary-foreground/70">
              <li><Link to="/" className="hover:text-gold transition-colors">Home</Link></li>
              <li><Link to="/properties?type=sale" className="hover:text-gold transition-colors">Buy Property</Link></li>
              <li><Link to="/properties?type=rent" className="hover:text-gold transition-colors">Rent Property</Link></li>
              <li><Link to="/contact" className="hover:text-gold transition-colors">Contact Us</Link></li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="font-display font-semibold text-gold mb-5">Contact Us</h4>
            <ul className="space-y-4 font-body text-sm text-primary-foreground/70">
              <li className="flex items-start gap-3">
                <MapPin className="w-4 h-4 text-gold mt-0.5 shrink-0" />
                <span>
                  {getSetting("address_bd", "Dhaka, Bangladesh")}<br />
                  {getSetting("address_dubai", "Dubai, UAE")}
                </span>
              </li>
              <li className="flex items-center gap-3">
                <Phone className="w-4 h-4 text-gold shrink-0" />
                <a href={`tel:${getSetting("phone_bd", "+8801700000000")}`} className="hover:text-gold transition-colors">
                  {getSetting("phone_bd", "+880 170 000 0000")}
                </a>
              </li>
              <li className="flex items-center gap-3">
                <Mail className="w-4 h-4 text-gold shrink-0" />
                <a href={`mailto:${getSetting("email", "info@skylineholding.com")}`} className="hover:text-gold transition-colors">
                  {getSetting("email", "info@skylineholding.com")}
                </a>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-primary-foreground/10 mt-12 pt-8 flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="font-body text-sm text-primary-foreground/50">
            © {new Date().getFullYear()} {getSetting("site_title", "Skyline Holding Ltd")}. All rights reserved.
          </p>
          <p className="font-body text-sm text-primary-foreground/50">Bangladesh • Dubai</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
