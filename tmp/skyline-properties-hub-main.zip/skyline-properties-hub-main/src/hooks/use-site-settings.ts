import { useQuery } from "@tanstack/react-query";
import { getSiteSettings } from "@/lib/api";

export type SiteSetting = { key: string; value: string };

export function useSiteSettings() {
  const { data: settings = [], isLoading } = useQuery({
    queryKey: ["site-settings"],
    queryFn: getSiteSettings,
    staleTime: 60_000,
  });

  const getSetting = (key: string, fallback: string): string => {
    const entry = (settings as SiteSetting[]).find((s) => s.key === key);
    return entry?.value?.trim() ?? fallback;
  };

  return { settings: settings as SiteSetting[], getSetting, isLoading };
}
