import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { useState } from "react";
import { MapPin, Phone, Mail, Clock, Send } from "lucide-react";
import { useMutation } from "@tanstack/react-query";
import { submitContactInquiry } from "@/lib/api";
import { useToast } from "@/hooks/use-toast";
import { useSiteSettings } from "@/hooks/use-site-settings";

const Contact = () => {
  const { toast } = useToast();
  const { getSetting } = useSiteSettings();
  const [form, setForm] = useState({ name: "", email: "", phone: "", message: "" });

  const mutation = useMutation({
    mutationFn: (values: typeof form) => submitContactInquiry(values),
    onSuccess: () => {
      toast({ title: "Message Sent!", description: "We'll be in touch within 24 hours." });
      setForm({ name: "", email: "", phone: "", message: "" });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to send. Please try again.", variant: "destructive" });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name || !form.email || !form.message) return;
    mutation.mutate(form);
  };

  const contactInfo = [
    {
      icon: MapPin,
      title: "Bangladesh Office",
      details: [getSetting("address_bd", "Gulshan 2, Dhaka 1212, Bangladesh")],
    },
    {
      icon: MapPin,
      title: "Dubai Office",
      details: [getSetting("address_dubai", "Downtown Dubai, UAE")],
    },
    {
      icon: Phone,
      title: "Phone",
      details: [
        getSetting("phone_bd", "+880 170 000 0000"),
        getSetting("phone_dubai", "+971 4 000 0000"),
      ].filter(Boolean),
    },
    {
      icon: Mail,
      title: "Email",
      details: [getSetting("email", "info@skylineholding.com")],
    },
    {
      icon: Clock,
      title: "Working Hours",
      details: ["Sat–Thu: 9AM – 7PM", "Friday: 2PM – 7PM"],
    },
  ];

  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      {/* Header */}
      <div className="bg-primary pt-20">
        <div className="container mx-auto px-4 py-16 text-center">
          <div className="flex items-center justify-center gap-2 mb-3">
            <div className="h-px w-8 bg-gold" />
            <span className="font-body text-gold text-sm font-medium tracking-widest uppercase">
              Get In Touch
            </span>
            <div className="h-px w-8 bg-gold" />
          </div>
          <h1 className="font-display text-4xl md:text-5xl font-bold text-primary-foreground">
            Contact Us
          </h1>
          <p className="font-body text-primary-foreground/70 mt-4 max-w-md mx-auto">
            Whether you're looking to buy, rent, or sell — our team is ready to help.
          </p>
        </div>
      </div>

      <div className="container mx-auto px-4 py-16">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
          {/* Contact Info */}
          <div className="space-y-6">
            {contactInfo.map((item) => (
              <div key={item.title} className="flex gap-4">
                <div className="w-10 h-10 bg-gold/10 rounded-full flex items-center justify-center shrink-0 mt-0.5">
                  <item.icon className="w-4 h-4 text-gold" />
                </div>
                <div>
                  <div className="font-display font-semibold text-foreground mb-1">{item.title}</div>
                  {item.details.map((d, i) => (
                    <div key={i} className="font-body text-muted-foreground text-sm">{d}</div>
                  ))}
                </div>
              </div>
            ))}
          </div>

          {/* Contact Form */}
          <div className="lg:col-span-2">
            <div className="bg-card rounded-xl shadow-card p-8">
              <h2 className="font-display text-2xl font-bold text-foreground mb-6">
                Send Us a Message
              </h2>

              <form onSubmit={handleSubmit} className="space-y-5">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                  <div>
                    <label className="font-body text-sm font-medium text-foreground block mb-2">
                      Full Name *
                    </label>
                    <input
                      type="text"
                      value={form.name}
                      onChange={(e) => setForm((p) => ({ ...p, name: e.target.value }))}
                      required
                      placeholder="John Doe"
                      className="w-full bg-background border border-border rounded-lg px-4 py-3 font-body text-sm text-foreground placeholder:text-muted-foreground outline-none focus:border-gold focus:ring-2 focus:ring-gold/20 transition-all duration-200"
                    />
                  </div>
                  <div>
                    <label className="font-body text-sm font-medium text-foreground block mb-2">
                      Email Address *
                    </label>
                    <input
                      type="email"
                      value={form.email}
                      onChange={(e) => setForm((p) => ({ ...p, email: e.target.value }))}
                      required
                      placeholder="john@example.com"
                      className="w-full bg-background border border-border rounded-lg px-4 py-3 font-body text-sm text-foreground placeholder:text-muted-foreground outline-none focus:border-gold focus:ring-2 focus:ring-gold/20 transition-all duration-200"
                    />
                  </div>
                </div>

                <div>
                  <label className="font-body text-sm font-medium text-foreground block mb-2">
                    Phone Number
                  </label>
                  <input
                    type="tel"
                    value={form.phone}
                    onChange={(e) => setForm((p) => ({ ...p, phone: e.target.value }))}
                    placeholder="+880 170 000 0000"
                    className="w-full bg-background border border-border rounded-lg px-4 py-3 font-body text-sm text-foreground placeholder:text-muted-foreground outline-none focus:border-gold transition-colors"
                  />
                </div>

                <div>
                  <label className="font-body text-sm font-medium text-foreground block mb-2">
                    Message *
                  </label>
                  <textarea
                    value={form.message}
                    onChange={(e) => setForm((p) => ({ ...p, message: e.target.value }))}
                    required
                    rows={6}
                    placeholder="Tell us about what you're looking for..."
                    className="w-full bg-background border border-border rounded-lg px-4 py-3 font-body text-sm text-foreground placeholder:text-muted-foreground outline-none focus:border-gold focus:ring-2 focus:ring-gold/20 transition-all duration-200 resize-none"
                  />
                </div>

                <button
                  type="submit"
                  disabled={mutation.isPending}
                  className="flex items-center gap-2 px-8 py-4 bg-gradient-gold text-primary font-body font-semibold rounded-lg shadow-gold hover:opacity-90 hover:shadow-lg transition-all duration-200 disabled:opacity-60"
                >
                  <Send className="w-4 h-4" />
                  {mutation.isPending ? "Sending..." : "Send Message"}
                </button>
              </form>
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
};

export default Contact;
