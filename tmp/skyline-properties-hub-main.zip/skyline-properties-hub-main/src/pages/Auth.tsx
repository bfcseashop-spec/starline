import { useState, useEffect } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { getSession, login, signup } from "@/lib/api";
import { useToast } from "@/hooks/use-toast";
import { Eye, EyeOff, LogIn, UserPlus, ShieldCheck, User } from "lucide-react";
import { Link } from "react-router-dom";

type AuthMode = "admin" | "customer";
type CustomerView = "login" | "signup";

const Auth = () => {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const { toast } = useToast();

  const defaultMode = (searchParams.get("mode") as AuthMode) || "customer";
  const [activeMode, setActiveMode] = useState<AuthMode>(defaultMode);
  const [customerView, setCustomerView] = useState<CustomerView>("login");
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);

  const [adminForm, setAdminForm] = useState({ email: "", password: "" });
  const [customerForm, setCustomerForm] = useState({ email: "", password: "", fullName: "" });

  useEffect(() => {
    getSession().then((session) => {
      if (session) navigate("/admin");
    });
  }, [navigate]);

  const handleAdminSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      await login(adminForm.email, adminForm.password, true);
      navigate("/admin");
    } catch (err: any) {
      toast({ title: "Admin Login Failed", description: err.message, variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  const handleCustomerSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      if (customerView === "login") {
        await login(customerForm.email, customerForm.password);
        toast({ title: "Welcome back!", description: "You're now logged in." });
        navigate("/properties");
      } else {
        await signup(customerForm.email, customerForm.password, customerForm.fullName);
        toast({ title: "Account Created!", description: "You're now logged in." });
        navigate("/properties");
      }
    } catch (err: any) {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  const inputClass =
    "w-full bg-background border border-border rounded-lg px-4 py-3 font-body text-sm text-foreground placeholder:text-muted-foreground outline-none focus:border-gold transition-colors";

  return (
    <div className="min-h-screen bg-primary flex flex-col items-center justify-center px-4 py-12">
      {/* Ambient blobs */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        <div className="absolute -top-24 -right-24 w-96 h-96 rounded-full bg-gold opacity-5 blur-3xl" />
        <div className="absolute -bottom-24 -left-24 w-72 h-72 rounded-full bg-gold opacity-5 blur-3xl" />
      </div>

      <div className="relative w-full max-w-4xl">
        {/* Header */}
        <div className="text-center mb-10">
          <Link to="/" className="inline-flex flex-col items-center gap-2">
            <div className="w-14 h-14 bg-gradient-gold rounded-xl flex items-center justify-center shadow-gold">
              <span className="font-display font-bold text-primary text-xl">SH</span>
            </div>
            <div className="font-display font-bold text-primary-foreground text-2xl">
              Skyline Holding Ltd
            </div>
          </Link>
          <p className="text-gold text-xs font-body tracking-widest uppercase mt-1">
            Secure Access Portal
          </p>
        </div>

        {/* Mode Toggle */}
        <div className="flex rounded-2xl bg-primary-foreground/5 border border-gold/20 p-1 mb-8 max-w-sm mx-auto">
          <button
            onClick={() => setActiveMode("customer")}
            className={`flex-1 flex items-center justify-center gap-2 py-3 px-4 rounded-xl font-body font-medium text-sm transition-all duration-200 ${
              activeMode === "customer"
                ? "bg-gradient-gold text-primary shadow-gold"
                : "text-primary-foreground/60 hover:text-primary-foreground/90"
            }`}
          >
            <User className="w-4 h-4" />
            Customer
          </button>
          <button
            onClick={() => setActiveMode("admin")}
            className={`flex-1 flex items-center justify-center gap-2 py-3 px-4 rounded-xl font-body font-medium text-sm transition-all duration-200 ${
              activeMode === "admin"
                ? "bg-gradient-gold text-primary shadow-gold"
                : "text-primary-foreground/60 hover:text-primary-foreground/90"
            }`}
          >
            <ShieldCheck className="w-4 h-4" />
            Admin
          </button>
        </div>

        {/* Panels */}
        <div className="grid md:grid-cols-2 gap-6">

          {/* ── Customer Panel ── */}
          <div
            className={`bg-card rounded-2xl shadow-lg p-8 transition-all duration-300 ${
              activeMode === "customer"
                ? "ring-2 ring-gold/40 scale-100 opacity-100"
                : "opacity-40 scale-95 pointer-events-none"
            }`}
          >
            {/* Panel header */}
            <div className="flex items-center gap-3 mb-6">
              <div className="w-10 h-10 rounded-xl bg-secondary flex items-center justify-center">
                <User className="w-5 h-5 text-gold" />
              </div>
              <div>
                <h2 className="font-display text-xl font-bold text-foreground">
                  {customerView === "login" ? "Customer Login" : "Create Account"}
                </h2>
                <p className="font-body text-xs text-muted-foreground">
                  {customerView === "login"
                    ? "Access your saved properties & inquiries"
                    : "Join to save properties & get updates"}
                </p>
              </div>
            </div>

            <form onSubmit={handleCustomerSubmit} className="space-y-4">
              {customerView === "signup" && (
                <div>
                  <label className="font-body text-sm font-medium text-foreground block mb-2">
                    Full Name
                  </label>
                  <input
                    type="text"
                    value={customerForm.fullName}
                    onChange={(e) => setCustomerForm((p) => ({ ...p, fullName: e.target.value }))}
                    required
                    placeholder="Your full name"
                    className={inputClass}
                  />
                </div>
              )}

              <div>
                <label className="font-body text-sm font-medium text-foreground block mb-2">
                  Email Address
                </label>
                <input
                  type="email"
                  value={customerForm.email}
                  onChange={(e) => setCustomerForm((p) => ({ ...p, email: e.target.value }))}
                  required
                  placeholder="you@email.com"
                  className={inputClass}
                />
              </div>

              <div>
                <label className="font-body text-sm font-medium text-foreground block mb-2">
                  Password
                </label>
                <div className="relative">
                  <input
                    type={showPassword ? "text" : "password"}
                    value={customerForm.password}
                    onChange={(e) => setCustomerForm((p) => ({ ...p, password: e.target.value }))}
                    required
                    placeholder="••••••••"
                    className={`${inputClass} pr-12`}
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <button
                type="submit"
                disabled={loading || activeMode !== "customer"}
                className="w-full flex items-center justify-center gap-2 py-3 bg-gradient-gold text-primary font-body font-semibold rounded-lg shadow-gold hover:opacity-90 transition-opacity disabled:opacity-60 mt-2"
              >
                {customerView === "login" ? (
                  <><LogIn className="w-4 h-4" />{loading ? "Signing in…" : "Sign In"}</>
                ) : (
                  <><UserPlus className="w-4 h-4" />{loading ? "Creating…" : "Create Account"}</>
                )}
              </button>
            </form>

            <div className="mt-5 text-center">
              <button
                onClick={() => setCustomerView(customerView === "login" ? "signup" : "login")}
                className="font-body text-sm text-muted-foreground hover:text-gold transition-colors"
              >
                {customerView === "login"
                  ? "Don't have an account? Sign up"
                  : "Already have an account? Sign in"}
              </button>
            </div>
          </div>

          {/* ── Admin Panel ── */}
          <div
            className={`bg-card rounded-2xl shadow-lg p-8 transition-all duration-300 ${
              activeMode === "admin"
                ? "ring-2 ring-gold/40 scale-100 opacity-100"
                : "opacity-40 scale-95 pointer-events-none"
            }`}
          >
            {/* Panel header */}
            <div className="flex items-center gap-3 mb-6">
              <div className="w-10 h-10 rounded-xl bg-primary flex items-center justify-center">
                <ShieldCheck className="w-5 h-5 text-gold" />
              </div>
              <div>
                <h2 className="font-display text-xl font-bold text-foreground">Admin Login</h2>
                <p className="font-body text-xs text-muted-foreground">
                  Restricted — authorised personnel only
                </p>
              </div>
            </div>

            {/* Security notice */}
            <div className="flex items-start gap-2 bg-gold/10 border border-gold/20 rounded-lg px-4 py-3 mb-5">
              <ShieldCheck className="w-4 h-4 text-gold shrink-0 mt-0.5" />
              <p className="font-body text-xs text-foreground/80">
                Access to the admin dashboard is restricted. Only verified admins can log in here.
              </p>
            </div>

            <form onSubmit={handleAdminSubmit} className="space-y-4">
              <div>
                <label className="font-body text-sm font-medium text-foreground block mb-2">
                  Admin Email
                </label>
                <input
                  type="email"
                  value={adminForm.email}
                  onChange={(e) => setAdminForm((p) => ({ ...p, email: e.target.value }))}
                  required
                  placeholder="admin@skylineholding.com"
                  className={inputClass}
                />
              </div>

              <div>
                <label className="font-body text-sm font-medium text-foreground block mb-2">
                  Password
                </label>
                <div className="relative">
                  <input
                    type={showPassword ? "text" : "password"}
                    value={adminForm.password}
                    onChange={(e) => setAdminForm((p) => ({ ...p, password: e.target.value }))}
                    required
                    placeholder="••••••••"
                    className={`${inputClass} pr-12`}
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <button
                type="submit"
                disabled={loading || activeMode !== "admin"}
                className="w-full flex items-center justify-center gap-2 py-3 bg-primary border border-gold/30 text-primary-foreground font-body font-semibold rounded-lg hover:bg-primary/80 transition-colors disabled:opacity-60 mt-2"
              >
                <ShieldCheck className="w-4 h-4 text-gold" />
                {loading ? "Verifying…" : "Admin Sign In"}
              </button>
            </form>

            <div className="mt-5 text-center">
              <p className="font-body text-xs text-muted-foreground">
                Not an admin?{" "}
                <button
                  onClick={() => setActiveMode("customer")}
                  className="text-gold hover:underline"
                >
                  Use customer login
                </button>
              </p>
            </div>
          </div>

        </div>

        {/* Back to site */}
        <div className="text-center mt-8">
          <Link
            to="/"
            className="font-body text-sm text-primary-foreground/50 hover:text-primary-foreground/80 transition-colors"
          >
            ← Back to Skyline Holding
          </Link>
        </div>
      </div>
    </div>
  );
};

export default Auth;
