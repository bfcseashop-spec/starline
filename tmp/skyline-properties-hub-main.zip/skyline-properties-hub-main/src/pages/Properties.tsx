import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import PropertyCard from "@/components/PropertyCard";
import { useState, useEffect } from "react";
import { useSearchParams } from "react-router-dom";
import { Search, SlidersHorizontal, X } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { getProperties } from "@/lib/api";

const PROPERTY_TYPES = ["apartment", "villa", "office", "commercial", "land", "penthouse"];
const CITIES = ["Dhaka", "Chittagong", "Sylhet", "Dubai"];
const COUNTRIES = ["Bangladesh", "UAE"];

const Properties = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const [showFilters, setShowFilters] = useState(false);

  const [filters, setFilters] = useState({
    q: searchParams.get("q") || "",
    type: searchParams.get("type") || "all",
    propertyType: searchParams.get("propertyType") || "all",
    city: searchParams.get("city") || "all",
    country: searchParams.get("country") || "all",
    minPrice: searchParams.get("minPrice") || "",
    maxPrice: searchParams.get("maxPrice") || "",
    bedrooms: searchParams.get("bedrooms") || "all",
  });

  const { data: properties = [], isLoading } = useQuery({
    queryKey: ["properties", filters],
    queryFn: () => getProperties(filters),
  });

  const updateFilter = (key: string, value: string) => {
    setFilters((prev) => ({ ...prev, [key]: value }));
  };

  const clearFilters = () => {
    setFilters({ q: "", type: "all", propertyType: "all", city: "all", country: "all", minPrice: "", maxPrice: "", bedrooms: "all" });
  };

  const hasActiveFilters = filters.q || filters.type !== "all" || filters.propertyType !== "all" || filters.city !== "all" || filters.country !== "all" || filters.minPrice || filters.maxPrice || filters.bedrooms !== "all";

  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      {/* Page Header */}
      <div className="bg-primary pt-20">
        <div className="container mx-auto px-4 py-12">
          <div className="flex items-center gap-2 mb-3">
            <div className="h-px w-8 bg-gold" />
            <span className="font-body text-gold text-sm font-medium tracking-widest uppercase">
              All Listings
            </span>
          </div>
          <h1 className="font-display text-4xl md:text-5xl font-bold text-primary-foreground">
            Browse Properties
          </h1>
          <p className="font-body text-primary-foreground/70 mt-3">
            {isLoading ? "Loading..." : `${properties.length} properties found`}
          </p>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        {/* Search + Filter Bar */}
        <div className="bg-card rounded-xl shadow-card p-4 mb-8 flex flex-col md:flex-row gap-4">
          <div className="flex-1 flex items-center gap-3 bg-background rounded-lg px-4 border border-border focus-within:border-gold/50 focus-within:ring-2 focus-within:ring-gold/20 transition-all duration-200">
            <Search className="w-4 h-4 text-muted-foreground shrink-0" />
            <input
              type="text"
              value={filters.q}
              onChange={(e) => updateFilter("q", e.target.value)}
              placeholder="Search by location, title..."
              className="flex-1 py-3 bg-transparent font-body text-sm text-foreground placeholder:text-muted-foreground outline-none"
            />
          </div>

          <div className="flex gap-2">
            {["all", "sale", "rent"].map((type) => (
              <button
                key={type}
                onClick={() => updateFilter("type", type)}
                className={`px-4 py-2 rounded-lg font-body text-sm font-medium transition-all duration-200 ${
                  filters.type === type
                    ? "bg-primary text-primary-foreground"
                    : "bg-secondary text-secondary-foreground hover:bg-muted"
                }`}
              >
                {type === "all" ? "All" : type === "sale" ? "Buy" : "Rent"}
              </button>
            ))}

            <button
              onClick={() => setShowFilters(!showFilters)}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg font-body text-sm font-medium border transition-all duration-200 ${
                showFilters ? "border-gold text-gold bg-gold/5" : "border-border text-foreground hover:border-gold hover:text-gold"
              }`}
            >
              <SlidersHorizontal className="w-4 h-4" />
              Filters
            </button>

            {hasActiveFilters && (
              <button
                onClick={clearFilters}
                className="flex items-center gap-1.5 px-3 py-2 rounded-lg font-body text-sm text-muted-foreground hover:text-destructive transition-colors"
              >
                <X className="w-4 h-4" />
                Clear
              </button>
            )}
          </div>
        </div>

        {/* Extended Filters */}
        {showFilters && (
          <div className="bg-card rounded-xl shadow-card p-6 mb-8 grid grid-cols-2 md:grid-cols-4 gap-4">
            <div>
              <label className="font-body text-xs text-muted-foreground font-medium uppercase tracking-wide block mb-2">
                Property Type
              </label>
              <select
                value={filters.propertyType}
                onChange={(e) => updateFilter("propertyType", e.target.value)}
                className="w-full bg-background border border-border rounded-lg px-3 py-2 font-body text-sm text-foreground outline-none focus:border-gold"
              >
                <option value="all">All Types</option>
                {PROPERTY_TYPES.map((t) => (
                  <option key={t} value={t} className="capitalize">{t.charAt(0).toUpperCase() + t.slice(1)}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="font-body text-xs text-muted-foreground font-medium uppercase tracking-wide block mb-2">
                City
              </label>
              <select
                value={filters.city}
                onChange={(e) => updateFilter("city", e.target.value)}
                className="w-full bg-background border border-border rounded-lg px-3 py-2 font-body text-sm text-foreground outline-none focus:border-gold"
              >
                <option value="all">All Cities</option>
                {CITIES.map((c) => (
                  <option key={c} value={c}>{c}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="font-body text-xs text-muted-foreground font-medium uppercase tracking-wide block mb-2">
                Country
              </label>
              <select
                value={filters.country}
                onChange={(e) => updateFilter("country", e.target.value)}
                className="w-full bg-background border border-border rounded-lg px-3 py-2 font-body text-sm text-foreground outline-none focus:border-gold"
              >
                <option value="all">All Countries</option>
                {COUNTRIES.map((c) => (
                  <option key={c} value={c}>{c}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="font-body text-xs text-muted-foreground font-medium uppercase tracking-wide block mb-2">
                Min Bedrooms
              </label>
              <select
                value={filters.bedrooms}
                onChange={(e) => updateFilter("bedrooms", e.target.value)}
                className="w-full bg-background border border-border rounded-lg px-3 py-2 font-body text-sm text-foreground outline-none focus:border-gold"
              >
                <option value="all">Any</option>
                {[1, 2, 3, 4, 5].map((n) => (
                  <option key={n} value={n}>{n}+</option>
                ))}
              </select>
            </div>

            <div>
              <label className="font-body text-xs text-muted-foreground font-medium uppercase tracking-wide block mb-2">
                Min Price
              </label>
              <input
                type="number"
                value={filters.minPrice}
                onChange={(e) => updateFilter("minPrice", e.target.value)}
                placeholder="0"
                className="w-full bg-background border border-border rounded-lg px-3 py-2 font-body text-sm text-foreground outline-none focus:border-gold"
              />
            </div>

            <div>
              <label className="font-body text-xs text-muted-foreground font-medium uppercase tracking-wide block mb-2">
                Max Price
              </label>
              <input
                type="number"
                value={filters.maxPrice}
                onChange={(e) => updateFilter("maxPrice", e.target.value)}
                placeholder="Any"
                className="w-full bg-background border border-border rounded-lg px-3 py-2 font-body text-sm text-foreground outline-none focus:border-gold"
              />
            </div>
          </div>
        )}

        {/* Results */}
        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[1, 2, 3, 4, 5, 6].map((i) => (
              <div key={i} className="bg-card rounded-xl overflow-hidden shadow-card">
                <div className="aspect-[4/3] bg-muted animate-pulse" />
                <div className="p-5 space-y-3">
                  <div className="h-5 bg-muted rounded animate-pulse" />
                  <div className="h-4 bg-muted rounded w-2/3 animate-pulse" />
                  <div className="h-6 bg-muted rounded w-1/3 animate-pulse" />
                </div>
              </div>
            ))}
          </div>
        ) : properties.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {properties.map((property) => (
              <PropertyCard key={property.id} property={property} />
            ))}
          </div>
        ) : (
          <div className="text-center py-24">
            <div className="w-20 h-20 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
              <Search className="w-8 h-8 text-muted-foreground" />
            </div>
            <h3 className="font-display text-2xl font-semibold text-foreground mb-2">
              No Properties Found
            </h3>
            <p className="font-body text-muted-foreground text-sm mb-6">
              Try adjusting your search or filters.
            </p>
            <button
              onClick={clearFilters}
              className="px-6 py-3 bg-primary text-primary-foreground font-body font-semibold text-sm rounded-lg"
            >
              Clear All Filters
            </button>
          </div>
        )}
      </div>

      <Footer />
    </div>
  );
};

export default Properties;
