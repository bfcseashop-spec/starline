import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { useState, useEffect, useCallback } from "react";
import { useParams, Link } from "react-router-dom";
import {
  MapPin, Bed, Bath, Maximize, Phone, Mail, ArrowLeft,
  ChevronLeft, ChevronRight, Play, X, ZoomIn, Image as ImageIcon, Video, Grid3X3,
  Calculator, TrendingDown, CalendarDays, Clock
} from "lucide-react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { getProperty, getPropertyMedia, submitContactInquiry } from "@/lib/api";
import { useToast } from "@/hooks/use-toast";

const PropertyDetail = () => {
  const { id } = useParams<{ id: string }>();
  const { toast } = useToast();
  const [lightboxOpen, setLightboxOpen] = useState(false);
  const [lightboxIdx, setLightboxIdx] = useState(0);
  const [contactForm, setContactForm] = useState({ name: "", email: "", phone: "", message: "" });

  const { data: property, isLoading } = useQuery({
    queryKey: ["property", id],
    queryFn: () => getProperty(id!),
    enabled: !!id,
  });

  const { data: media = [] } = useQuery({
    queryKey: ["property-media", id],
    queryFn: () => getPropertyMedia(id!),
    enabled: !!id,
  });

  const inquiryMutation = useMutation({
    mutationFn: (values: typeof contactForm) =>
      submitContactInquiry({ property_id: id ?? undefined, ...values }),
    onSuccess: () => {
      toast({ title: "Inquiry Sent!", description: "Our team will contact you shortly." });
      setContactForm({ name: "", email: "", phone: "", message: "" });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to send inquiry. Try again.", variant: "destructive" });
    },
  });

  // Merge cover + gallery, deduplicate
  const allMedia = (() => {
    const coverItem = property?.cover_image_url
      ? [{ id: "cover", media_url: property.cover_image_url, media_type: "image" as const }]
      : [];
    const galleryItems = (media as any[]).filter(
      (m) => m.media_url !== property?.cover_image_url
    );
    return [...coverItem, ...galleryItems];
  })();

  const images = allMedia.filter((m) => m.media_type === "image");
  const videos = allMedia.filter((m) => m.media_type === "video");

  const openLightbox = useCallback((idx: number) => {
    setLightboxIdx(idx);
    setLightboxOpen(true);
    document.body.style.overflow = "hidden";
  }, []);

  const closeLightbox = useCallback(() => {
    setLightboxOpen(false);
    document.body.style.overflow = "";
  }, []);

  const prevSlide = useCallback(() => setLightboxIdx((i) => Math.max(0, i - 1)), []);
  const nextSlide = useCallback(() => setLightboxIdx((i) => Math.min(allMedia.length - 1, i + 1)), [allMedia.length]);

  useEffect(() => {
    if (!lightboxOpen) return;
    const handler = (e: KeyboardEvent) => {
      if (e.key === "ArrowLeft") prevSlide();
      if (e.key === "ArrowRight") nextSlide();
      if (e.key === "Escape") closeLightbox();
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [lightboxOpen, prevSlide, nextSlide, closeLightbox]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!contactForm.name || !contactForm.email || !contactForm.message) return;
    inquiryMutation.mutate(contactForm);
  };

  const formatPrice = (price: number, country: string) =>
    country === "UAE" ? `AED ${price.toLocaleString()}` : `BDT ${price.toLocaleString()}`;

  const currentMedia = allMedia[lightboxIdx];

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="pt-20 container mx-auto px-4 py-12">
          <div className="h-96 bg-muted animate-pulse rounded-xl mb-8" />
          <div className="h-8 bg-muted animate-pulse rounded w-1/2 mb-4" />
          <div className="h-4 bg-muted animate-pulse rounded w-1/3" />
        </div>
      </div>
    );
  }

  if (!property) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <h2 className="font-display text-2xl text-foreground mb-4">Property not found</h2>
          <Link to="/properties" className="text-gold font-body text-sm">← Back to properties</Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      {/* ── Fullscreen Lightbox ─────────────────────────────── */}
      {lightboxOpen && currentMedia && (
        <div className="fixed inset-0 z-[100] bg-black flex flex-col">
          {/* Top bar */}
          <div className="flex items-center justify-between px-4 py-3 bg-black/80 backdrop-blur-sm shrink-0">
            <div className="font-body text-sm text-white/60">
              <span className="text-white font-semibold">{lightboxIdx + 1}</span>
              <span className="mx-1">/</span>
              {allMedia.length}
            </div>
            <p className="font-body text-white/70 text-sm truncate max-w-xs">{property.title}</p>
            <button
              onClick={closeLightbox}
              className="w-9 h-9 bg-white/10 hover:bg-white/25 text-white rounded-full flex items-center justify-center transition-colors"
              aria-label="Close lightbox"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Main media area */}
          <div className="flex-1 relative flex items-center justify-center overflow-hidden">
            {/* Prev */}
            <button
              onClick={prevSlide}
              disabled={lightboxIdx === 0}
              className="absolute left-3 z-10 w-12 h-12 bg-white/10 hover:bg-white/25 disabled:opacity-20 disabled:cursor-not-allowed text-white rounded-full flex items-center justify-center transition-all"
            >
              <ChevronLeft className="w-6 h-6" />
            </button>

            {/* Media */}
            <div className="w-full h-full flex items-center justify-center px-16 py-4">
              {currentMedia.media_type === "video" ? (
                <video
                  key={currentMedia.id}
                  src={currentMedia.media_url}
                  controls
                  autoPlay
                  className="max-w-full max-h-full rounded-lg object-contain"
                />
              ) : (
                <img
                  key={currentMedia.id}
                  src={currentMedia.media_url}
                  alt={`${property.title} — photo ${lightboxIdx + 1}`}
                  className="max-w-full max-h-full rounded-lg object-contain select-none animate-fade-in"
                />
              )}
            </div>

            {/* Next */}
            <button
              onClick={nextSlide}
              disabled={lightboxIdx === allMedia.length - 1}
              className="absolute right-3 z-10 w-12 h-12 bg-white/10 hover:bg-white/25 disabled:opacity-20 disabled:cursor-not-allowed text-white rounded-full flex items-center justify-center transition-all"
            >
              <ChevronRight className="w-6 h-6" />
            </button>
          </div>

          {/* Bottom thumbnail strip */}
          {allMedia.length > 1 && (
            <div className="shrink-0 bg-black/80 backdrop-blur-sm px-4 py-3">
              <div className="flex gap-2 overflow-x-auto justify-center scrollbar-none pb-0.5">
                {allMedia.map((m, idx) => (
                  <button
                    key={m.id}
                    onClick={() => setLightboxIdx(idx)}
                    className={`relative w-16 h-11 rounded-lg overflow-hidden shrink-0 transition-all duration-200 ${
                      idx === lightboxIdx
                        ? "ring-2 ring-gold scale-105 opacity-100"
                        : "opacity-50 hover:opacity-80"
                    }`}
                  >
                    {m.media_type === "video" ? (
                      <div className="w-full h-full bg-white/10 flex items-center justify-center">
                        <Play className="w-3 h-3 text-white" />
                      </div>
                    ) : (
                      <img src={m.media_url} alt="" className="w-full h-full object-cover" />
                    )}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      <div className="pt-20">
        {/* Back */}
        <div className="container mx-auto px-4 py-4">
          <Link to="/properties" className="inline-flex items-center gap-2 font-body text-sm text-muted-foreground hover:text-gold transition-colors">
            <ArrowLeft className="w-4 h-4" /> Back to Properties
          </Link>
        </div>

        {/* ── Mosaic Gallery ─────────────────────────────────── */}
        {allMedia.length > 0 && (
          <div className="container mx-auto px-4 mb-8">
            {allMedia.length === 1 ? (
              /* Single image */
              <div
                className="relative rounded-2xl overflow-hidden cursor-zoom-in group"
                style={{ aspectRatio: "16/9" }}
                onClick={() => openLightbox(0)}
              >
                <img
                  src={allMedia[0].media_url}
                  alt={property.title}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors flex items-center justify-center">
                  <div className="opacity-0 group-hover:opacity-100 transition-opacity w-14 h-14 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center">
                    <ZoomIn className="w-6 h-6 text-white" />
                  </div>
                </div>
              </div>
            ) : allMedia.length === 2 ? (
              /* Two images side by side */
              <div className="grid grid-cols-2 gap-2 rounded-2xl overflow-hidden" style={{ height: "480px" }}>
                {allMedia.slice(0, 2).map((m, idx) => (
                  <GalleryCell key={m.id} media={m} idx={idx} onClick={() => openLightbox(idx)} />
                ))}
              </div>
            ) : allMedia.length === 3 ? (
              /* 1 big left + 2 stacked right */
              <div className="grid grid-cols-2 gap-2 rounded-2xl overflow-hidden" style={{ height: "500px" }}>
                <GalleryCell media={allMedia[0]} idx={0} onClick={() => openLightbox(0)} className="row-span-2" />
                <GalleryCell media={allMedia[1]} idx={1} onClick={() => openLightbox(1)} />
                <GalleryCell media={allMedia[2]} idx={2} onClick={() => openLightbox(2)} />
              </div>
            ) : allMedia.length === 4 ? (
              /* 1 big left + 3 stacked right */
              <div className="grid grid-cols-3 gap-2 rounded-2xl overflow-hidden" style={{ height: "500px" }}>
                <div className="col-span-2 row-span-3">
                  <GalleryCell media={allMedia[0]} idx={0} onClick={() => openLightbox(0)} className="h-full" />
                </div>
                {allMedia.slice(1, 4).map((m, i) => (
                  <GalleryCell key={m.id} media={m} idx={i + 1} onClick={() => openLightbox(i + 1)} />
                ))}
              </div>
            ) : (
              /* 5+ images: hero + 4-grid right panel with "See all" overlay */
              <div className="grid grid-cols-4 grid-rows-2 gap-2 rounded-2xl overflow-hidden" style={{ height: "520px" }}>
                {/* Hero */}
                <div className="col-span-2 row-span-2">
                  <GalleryCell media={allMedia[0]} idx={0} onClick={() => openLightbox(0)} className="h-full" />
                </div>
                {/* 4 smaller cells */}
                {allMedia.slice(1, 5).map((m, i) => (
                  <div key={m.id} className="relative">
                    <GalleryCell media={m} idx={i + 1} onClick={() => openLightbox(i + 1)} className="h-full" />
                    {/* "See all" overlay on last cell if more than 5 */}
                    {i === 3 && allMedia.length > 5 && (
                      <button
                        onClick={() => openLightbox(4)}
                        className="absolute inset-0 bg-black/60 flex flex-col items-center justify-center text-white hover:bg-black/70 transition-colors"
                      >
                        <Grid3X3 className="w-6 h-6 mb-1" />
                        <span className="font-body text-sm font-semibold">+{allMedia.length - 5} more</span>
                      </button>
                    )}
                  </div>
                ))}
              </div>
            )}

            {/* Gallery meta bar */}
            <div className="flex items-center justify-between mt-3 px-1">
              <div className="flex items-center gap-3">
                {images.length > 0 && (
                  <span className="flex items-center gap-1.5 font-body text-xs text-muted-foreground">
                    <ImageIcon className="w-3.5 h-3.5 text-gold" />
                    {images.length} {images.length === 1 ? "Photo" : "Photos"}
                  </span>
                )}
                {videos.length > 0 && (
                  <span className="flex items-center gap-1.5 font-body text-xs text-muted-foreground">
                    <Video className="w-3.5 h-3.5 text-gold" />
                    {videos.length} {videos.length === 1 ? "Video" : "Videos"}
                  </span>
                )}
              </div>
              {allMedia.length > 1 && (
                <button
                  onClick={() => openLightbox(0)}
                  className="flex items-center gap-1.5 font-body text-xs text-muted-foreground hover:text-gold transition-colors"
                >
                  <ZoomIn className="w-3.5 h-3.5" /> View all in fullscreen
                </button>
              )}
            </div>
          </div>
        )}

        {/* No media fallback */}
        {allMedia.length === 0 && (
          <div className="container mx-auto px-4 mb-8">
            <div className="aspect-video rounded-2xl bg-muted flex items-center justify-center">
              <div className="text-center">
                <MapPin className="w-16 h-16 text-muted-foreground mx-auto mb-2" />
                <p className="font-body text-muted-foreground text-sm">No photos available</p>
              </div>
            </div>
          </div>
        )}

        {/* ── Property Info ─────────────────────────────── */}
        <div className="container mx-auto px-4 pb-16">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
            {/* Main Info */}
            <div className="lg:col-span-2">
              <div className="flex flex-wrap items-center gap-2 mb-4">
                <span className={`px-3 py-1 rounded font-body text-xs font-semibold uppercase tracking-wide ${
                  property.price_type === "sale" ? "bg-primary text-primary-foreground" : "bg-gold text-primary"
                }`}>
                  {property.price_type === "sale" ? "For Sale" : "For Rent"}
                </span>
                <span className="px-3 py-1 rounded bg-secondary text-secondary-foreground font-body text-xs capitalize">
                  {property.property_type}
                </span>
                <span className={`px-3 py-1 rounded font-body text-xs font-semibold uppercase ${
                  property.status === "available" ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"
                }`}>
                  {property.status}
                </span>
              </div>

              <h1 className="font-display text-3xl md:text-4xl font-bold text-foreground mb-3">
                {property.title}
              </h1>

              <div className="flex items-center gap-2 text-muted-foreground mb-6">
                <MapPin className="w-4 h-4 text-gold" />
                <span className="font-body">{property.address}, {property.city}, {property.country}</span>
              </div>

              <div className="text-3xl font-display font-bold text-gold mb-8">
                {formatPrice(property.price, property.country)}
                {property.price_type === "rent" && (
                  <span className="text-sm font-body text-muted-foreground ml-2">/month</span>
                )}
              </div>

              {/* Stats */}
              <div className="grid grid-cols-3 gap-4 bg-muted/30 rounded-xl p-6 mb-8">
                {property.bedrooms && (
                  <div className="text-center">
                    <Bed className="w-5 h-5 text-gold mx-auto mb-2" />
                    <div className="font-display font-bold text-foreground text-xl">{property.bedrooms}</div>
                    <div className="font-body text-muted-foreground text-xs">Bedrooms</div>
                  </div>
                )}
                {property.bathrooms && (
                  <div className="text-center">
                    <Bath className="w-5 h-5 text-gold mx-auto mb-2" />
                    <div className="font-display font-bold text-foreground text-xl">{property.bathrooms}</div>
                    <div className="font-body text-muted-foreground text-xs">Bathrooms</div>
                  </div>
                )}
                {property.area_sqft && (
                  <div className="text-center">
                    <Maximize className="w-5 h-5 text-gold mx-auto mb-2" />
                    <div className="font-display font-bold text-foreground text-xl">{property.area_sqft.toLocaleString()}</div>
                    <div className="font-body text-muted-foreground text-xs">Sqft</div>
                  </div>
                )}
              </div>

              {/* ── Installment Calculator ── */}
              {(property as any).is_installment && (
                <InstallmentCalculator
                  price={property.price}
                  defaultDownPct={(property as any).down_payment_pct ?? 20}
                  defaultYears={(property as any).installment_years ?? 5}
                  country={property.country}
                />
              )}

              {property.description && (
                <div>
                  <h2 className="font-display text-2xl font-semibold text-foreground mb-4">Description</h2>
                  <p className="font-body text-muted-foreground leading-relaxed whitespace-pre-line">
                    {property.description}
                  </p>
                </div>
              )}
            </div>

            {/* Contact Sidebar */}
            <div>
              <div className="bg-card rounded-xl shadow-card p-6 sticky top-24">
                <h3 className="font-display text-xl font-semibold text-foreground mb-2">
                  Interested in this property?
                </h3>
                <p className="font-body text-muted-foreground text-sm mb-6">
                  Send us an inquiry and our team will get back to you shortly.
                </p>

                <form onSubmit={handleSubmit} className="space-y-4">
                  <input type="text" value={contactForm.name} onChange={(e) => setContactForm((p) => ({ ...p, name: e.target.value }))}
                    placeholder="Your Name *" required
                    className="w-full bg-background border border-border rounded-lg px-4 py-3 font-body text-sm text-foreground placeholder:text-muted-foreground outline-none focus:border-gold transition-colors" />
                  <input type="email" value={contactForm.email} onChange={(e) => setContactForm((p) => ({ ...p, email: e.target.value }))}
                    placeholder="Email Address *" required
                    className="w-full bg-background border border-border rounded-lg px-4 py-3 font-body text-sm text-foreground placeholder:text-muted-foreground outline-none focus:border-gold transition-colors" />
                  <input type="tel" value={contactForm.phone} onChange={(e) => setContactForm((p) => ({ ...p, phone: e.target.value }))}
                    placeholder="Phone Number"
                    className="w-full bg-background border border-border rounded-lg px-4 py-3 font-body text-sm text-foreground placeholder:text-muted-foreground outline-none focus:border-gold transition-colors" />
                  <textarea value={contactForm.message} onChange={(e) => setContactForm((p) => ({ ...p, message: e.target.value }))}
                    placeholder="Your Message *" required rows={4}
                    className="w-full bg-background border border-border rounded-lg px-4 py-3 font-body text-sm text-foreground placeholder:text-muted-foreground outline-none focus:border-gold transition-colors resize-none" />
                  <button type="submit" disabled={inquiryMutation.isPending}
                    className="w-full py-3 bg-gradient-gold text-primary font-body font-semibold text-sm rounded-lg shadow-gold hover:opacity-90 transition-opacity disabled:opacity-60">
                    {inquiryMutation.isPending ? "Sending..." : "Send Inquiry"}
                  </button>
                </form>

                <div className="mt-6 pt-6 border-t border-border space-y-3">
                  <a href="tel:+8801700000000" className="flex items-center gap-3 font-body text-sm text-foreground hover:text-gold transition-colors">
                    <div className="w-9 h-9 bg-gold/10 rounded-full flex items-center justify-center">
                      <Phone className="w-4 h-4 text-gold" />
                    </div>
                    +880 170 000 0000
                  </a>
                  <a href="mailto:info@skylineholding.com" className="flex items-center gap-3 font-body text-sm text-foreground hover:text-gold transition-colors">
                    <div className="w-9 h-9 bg-gold/10 rounded-full flex items-center justify-center">
                      <Mail className="w-4 h-4 text-gold" />
                    </div>
                    info@skylineholding.com
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
};

/* ── Installment Calculator ─── */
interface InstallmentCalculatorProps {
  price: number;
  defaultDownPct: number;
  defaultYears: number;
  country: string;
}

const InstallmentCalculator = ({ price, defaultDownPct, defaultYears, country }: InstallmentCalculatorProps) => {
  const [downPct, setDownPct] = useState(defaultDownPct);
  const [years, setYears] = useState(defaultYears);

  const currency = country === "UAE" ? "AED" : "BDT";
  const fmt = (n: number) => `${currency} ${Math.round(n).toLocaleString()}`;

  const downAmount   = (price * downPct) / 100;
  const remaining    = price - downAmount;
  const totalMonths  = years * 12;
  const monthly      = remaining / totalMonths;
  const quarterly    = remaining / (years * 4);   // every 3 months
  const semiAnnual   = remaining / (years * 2);   // every 6 months

  const plans = [
    { label: "Monthly",           sublabel: "Every 1 month",  amount: monthly,    icon: CalendarDays, count: totalMonths },
    { label: "Quarterly",         sublabel: "Every 3 months", amount: quarterly,  icon: Clock,        count: years * 4 },
    { label: "Semi-Annual",       sublabel: "Every 6 months", amount: semiAnnual, icon: TrendingDown, count: years * 2 },
  ];

  return (
    <div className="mb-8 bg-gradient-to-br from-primary/5 to-gold/5 border border-gold/20 rounded-2xl overflow-hidden">
      {/* Header */}
      <div className="flex items-center gap-3 px-6 py-4 border-b border-gold/10 bg-primary/5">
        <div className="w-9 h-9 bg-gradient-gold rounded-xl flex items-center justify-center shadow-gold">
          <Calculator className="w-4 h-4 text-primary" />
        </div>
        <div>
          <h3 className="font-display font-semibold text-foreground text-lg">Installment Calculator</h3>
          <p className="font-body text-xs text-muted-foreground">Adjust options to see your payment plan</p>
        </div>
      </div>

      <div className="p-6 space-y-6">
        {/* Controls */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
          {/* Down Payment Slider */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="font-body text-sm font-medium text-foreground">Down Payment</label>
              <span className="font-display font-bold text-gold text-lg">{downPct}%</span>
            </div>
            <input
              type="range" min={5} max={50} step={5} value={downPct}
              onChange={(e) => setDownPct(Number(e.target.value))}
              className="w-full accent-gold cursor-pointer"
            />
            <div className="flex justify-between font-body text-xs text-muted-foreground mt-1">
              <span>5%</span><span>50%</span>
            </div>
            <div className="mt-2 px-3 py-2 bg-gold/10 rounded-lg">
              <span className="font-body text-xs text-muted-foreground">Down amount: </span>
              <span className="font-display font-bold text-gold text-sm">{fmt(downAmount)}</span>
            </div>
          </div>

          {/* Tenure Selector */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="font-body text-sm font-medium text-foreground">Tenure</label>
              <span className="font-display font-bold text-gold text-lg">{years} yrs</span>
            </div>
            <div className="grid grid-cols-3 gap-2">
              {[3, 5, 7, 10, 15, 20].map((y) => (
                <button
                  key={y}
                  type="button"
                  onClick={() => setYears(y)}
                  className={`py-2 rounded-lg font-body text-sm font-medium transition-all ${
                    years === y
                      ? "bg-gradient-gold text-primary shadow-gold"
                      : "bg-muted text-muted-foreground hover:bg-gold/10 hover:text-gold"
                  }`}
                >
                  {y} yr
                </button>
              ))}
            </div>
            <div className="mt-2 px-3 py-2 bg-gold/10 rounded-lg">
              <span className="font-body text-xs text-muted-foreground">Balance after down payment: </span>
              <span className="font-display font-bold text-gold text-sm">{fmt(remaining)}</span>
            </div>
          </div>
        </div>

        {/* Plan Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          {plans.map(({ label, sublabel, amount, icon: Icon, count }) => (
            <div key={label} className="bg-card border border-border rounded-xl p-4 flex flex-col gap-2 hover:border-gold/40 transition-colors">
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 bg-primary/10 rounded-lg flex items-center justify-center">
                  <Icon className="w-3.5 h-3.5 text-gold" />
                </div>
                <div>
                  <div className="font-body text-xs font-semibold text-foreground">{label}</div>
                  <div className="font-body text-[10px] text-muted-foreground">{sublabel}</div>
                </div>
              </div>
              <div className="font-display font-bold text-foreground text-xl">{fmt(amount)}</div>
              <div className="font-body text-[10px] text-muted-foreground">{count} payments × {fmt(amount)}</div>
            </div>
          ))}
        </div>

        {/* Summary bar */}
        <div className="flex flex-wrap items-center gap-4 px-4 py-3 bg-primary/5 rounded-xl border border-primary/10 text-xs font-body text-muted-foreground">
          <span>💰 Total price: <strong className="text-foreground">{fmt(price)}</strong></span>
          <span>⬇ Down: <strong className="text-gold">{fmt(downAmount)}</strong></span>
          <span>📅 Tenure: <strong className="text-foreground">{years} years</strong></span>
          <span>🔢 Total installment: <strong className="text-foreground">{fmt(remaining)}</strong></span>
        </div>
      </div>
    </div>
  );
};

/* ── Helper: individual gallery cell ─── */
interface GalleryCellProps {
  media: { id: string; media_url: string; media_type: string };
  idx: number;
  onClick: () => void;
  className?: string;
}

const GalleryCell = ({ media, idx, onClick, className = "" }: GalleryCellProps) => (
  <div
    onClick={onClick}
    className={`relative overflow-hidden cursor-pointer group bg-muted ${className}`}
    style={!className.includes("h-") ? { height: "100%" } : {}}
  >
    {media.media_type === "video" ? (
      <>
        <div className="w-full h-full bg-primary/10 flex items-center justify-center">
          <div className="w-14 h-14 bg-gold/90 rounded-full flex items-center justify-center shadow-gold">
            <Play className="w-6 h-6 text-primary ml-0.5" />
          </div>
        </div>
      </>
    ) : (
      <img
        src={media.media_url}
        alt={`Gallery photo ${idx + 1}`}
        className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
        loading={idx === 0 ? "eager" : "lazy"}
      />
    )}
    {/* Hover overlay */}
    <div className="absolute inset-0 bg-black/0 group-hover:bg-black/25 transition-colors duration-300 flex items-center justify-center">
      <div className="opacity-0 group-hover:opacity-100 transition-opacity duration-300 w-10 h-10 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center">
        <ZoomIn className="w-4 h-4 text-white" />
      </div>
    </div>
  </div>
);

export default PropertyDetail;
