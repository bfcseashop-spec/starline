import { useState, useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";
import {
  getSession,
  logout,
  getPropertyMedia,
  uploadPropertyMedia,
  deletePropertyMedia,
  getAdminProperties,
  getAdminContactInquiries,
  markInquiryRead,
  createProperty,
  updateProperty,
  deleteProperty,
  setPropertyFeatured,
  setPropertyCover,
  upsertSiteSetting,
  getAdminNavbarLinks,
  createNavbarLink,
  updateNavbarLink,
  deleteNavbarLink,
  reorderNavbarLinks,
  getAdminSocialIntegrations,
  upsertSocialIntegration,
  getSiteSettings,
} from "@/lib/api";
import { useToast } from "@/hooks/use-toast";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import {
  LayoutDashboard, Building2, MessageSquare, Plus, LogOut, Edit2, Trash2,
  Upload, X, Star, Settings, Check, Image as ImageIcon, Video,
  ChevronDown, ChevronUp, Eye, Globe, DollarSign, Share2,
  Youtube, Facebook, Instagram, Twitter, Linkedin, Phone,
  Menu, Link as LinkIcon, ToggleLeft, ToggleRight, Save, GripVertical,
  AlertCircle
} from "lucide-react";

/* ─────────────────────────────────────────────────────────────────────
   TYPES
──────────────────────────────────────────────────────────────────────*/
type AdminTab = "dashboard" | "properties" | "inquiries" | "navbar" | "currency" | "integrations" | "settings";

interface UploadItem {
  id: string; file: File; preview: string;
  type: "image" | "video"; progress: number;
  status: "pending" | "uploading" | "done" | "error"; url?: string;
}

/* ─────────────────────────────────────────────────────────────────────
   MEDIA MANAGER
──────────────────────────────────────────────────────────────────────*/
const MediaManager = ({ propertyId, onCoverSet }: { propertyId: string; onCoverSet: (url: string) => void }) => {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const dropRef = useRef<HTMLDivElement>(null);
  const [dragging, setDragging] = useState(false);
  const [uploads, setUploads] = useState<UploadItem[]>([]);
  const [expanded, setExpanded] = useState(true);

  const { data: media = [], refetch } = useQuery({
    queryKey: ["property-media", propertyId],
    queryFn: () => getPropertyMedia(propertyId),
  });

  const handleFiles = (files: FileList | null) => {
    if (!files) return;
    const newItems: UploadItem[] = Array.from(files).map((file) => ({
      id: `${Date.now()}-${Math.random()}`, file, preview: URL.createObjectURL(file),
      type: file.type.startsWith("video") ? "video" : "image", progress: 0, status: "pending",
    }));
    setUploads((prev) => [...prev, ...newItems]);
    newItems.forEach((item) => uploadFile(item));
  };

  const uploadFile = async (item: UploadItem) => {
    setUploads((prev) => prev.map((u) => u.id === item.id ? { ...u, status: "uploading" } : u));
    try {
      const row = await uploadPropertyMedia(propertyId, item.file);
      const url = row?.media_url ?? "";
      setUploads((prev) => prev.map((u) => u.id === item.id ? { ...u, status: "done", progress: 100, url } : u));
      refetch();
      queryClient.invalidateQueries({ queryKey: ["all-property-media"] });
      toast({ title: "✓ Uploaded", description: item.file.name });
    } catch (e: any) {
      setUploads((prev) => prev.map((u) => u.id === item.id ? { ...u, status: "error" } : u));
      toast({ title: "Upload failed", description: e?.message, variant: "destructive" });
    }
  };

  const deleteMedia = async (mediaId: string) => {
    await deletePropertyMedia(mediaId);
    refetch();
    queryClient.invalidateQueries({ queryKey: ["all-property-media"] });
    toast({ title: "Deleted" });
  };

  const setCover = (url: string) => { onCoverSet(url); toast({ title: "Cover image updated" }); };
  const onDragOver = (e: React.DragEvent) => { e.preventDefault(); setDragging(true); };
  const onDragLeave = () => setDragging(false);
  const onDrop = (e: React.DragEvent) => { e.preventDefault(); setDragging(false); handleFiles(e.dataTransfer.files); };
  const pendingUploads = uploads.filter((u) => u.status !== "done");

  return (
    <div className="mt-4 border border-border rounded-xl overflow-hidden">
      <button onClick={() => setExpanded(!expanded)} className="w-full flex items-center justify-between px-4 py-3 bg-muted/50 hover:bg-muted transition-colors">
        <div className="flex items-center gap-2 font-body text-sm font-medium text-foreground">
          <ImageIcon className="w-4 h-4 text-gold" />
          Media Gallery
          <span className="text-xs bg-gold/20 text-gold px-2 py-0.5 rounded-full">{media.length} files</span>
        </div>
        {expanded ? <ChevronUp className="w-4 h-4 text-muted-foreground" /> : <ChevronDown className="w-4 h-4 text-muted-foreground" />}
      </button>
      {expanded && (
        <div className="p-4 space-y-4">
          <div ref={dropRef} onDragOver={onDragOver} onDragLeave={onDragLeave} onDrop={onDrop}
            className={`relative border-2 border-dashed rounded-xl p-8 text-center transition-all ${dragging ? "border-gold bg-gold/5 scale-[1.01]" : "border-border hover:border-gold/50 hover:bg-muted/30"}`}>
            <input type="file" accept="image/*,video/*" multiple onChange={(e) => handleFiles(e.target.files)} className="absolute inset-0 w-full h-full opacity-0 cursor-pointer" />
            <div className="flex flex-col items-center gap-2 pointer-events-none">
              <div className="flex gap-3">
                <div className="w-10 h-10 bg-gold/10 rounded-full flex items-center justify-center"><ImageIcon className="w-5 h-5 text-gold" /></div>
                <div className="w-10 h-10 bg-gold/10 rounded-full flex items-center justify-center"><Video className="w-5 h-5 text-gold" /></div>
              </div>
              <p className="font-body font-medium text-foreground text-sm mt-1">{dragging ? "Drop files here!" : "Drag & drop photos or videos here"}</p>
              <p className="font-body text-muted-foreground text-xs">or click to browse • JPG, PNG, MP4, MOV supported</p>
              <div className="mt-2 px-4 py-1.5 bg-gradient-gold text-primary font-body text-xs font-semibold rounded-lg shadow-gold">Choose Files</div>
            </div>
          </div>
          {pendingUploads.length > 0 && (
            <div className="space-y-2">
              <p className="font-body text-xs text-muted-foreground font-medium uppercase tracking-wide">Uploading…</p>
              {pendingUploads.map((u) => (
                <div key={u.id} className="flex items-center gap-3 bg-muted/30 rounded-lg p-2.5">
                  <div className="w-10 h-10 rounded-lg overflow-hidden shrink-0 bg-muted">
                    {u.type === "image" ? <img src={u.preview} alt="" className="w-full h-full object-cover" /> : <div className="w-full h-full flex items-center justify-center"><Video className="w-4 h-4 text-muted-foreground" /></div>}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-body text-xs text-foreground truncate">{u.file.name}</p>
                    <div className="mt-1 h-1.5 bg-muted rounded-full overflow-hidden">
                      <div className={`h-full rounded-full transition-all duration-300 ${u.status === "error" ? "bg-destructive" : "bg-gold animate-pulse"}`} style={{ width: u.status === "uploading" ? "70%" : u.status === "error" ? "100%" : "0%" }} />
                    </div>
                  </div>
                  <span className={`font-body text-[10px] font-medium shrink-0 ${u.status === "error" ? "text-destructive" : "text-gold"}`}>{u.status === "error" ? "Failed" : "Uploading..."}</span>
                </div>
              ))}
            </div>
          )}
          {media.length > 0 && (
            <div>
              <p className="font-body text-xs text-muted-foreground font-medium uppercase tracking-wide mb-3">Uploaded Media — hover to manage</p>
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3">
                {media.map((m: any, idx: number) => (
                  <div key={m.id} className="group relative aspect-square rounded-xl overflow-hidden bg-muted border border-border hover:border-gold transition-colors">
                    {m.media_type === "image" ? <img src={m.media_url} alt="" className="w-full h-full object-cover" /> : (
                      <div className="w-full h-full flex flex-col items-center justify-center gap-1 bg-primary/10"><Video className="w-6 h-6 text-gold" /><span className="font-body text-[10px] text-muted-foreground">Video</span></div>
                    )}
                    <div className="absolute top-1.5 left-1.5 w-5 h-5 bg-primary/80 text-primary-foreground rounded-full flex items-center justify-center font-body text-[9px] font-bold">{idx + 1}</div>
                    <div className="absolute inset-0 bg-primary/75 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center gap-2 p-2">
                      {m.media_type === "image" && (
                        <button onClick={() => setCover(m.media_url)} className="w-full flex items-center justify-center gap-1 py-1.5 bg-gold text-primary font-body text-[10px] font-semibold rounded-lg"><Star className="w-3 h-3" /> Set Cover</button>
                      )}
                      <a href={m.media_url} target="_blank" rel="noreferrer" className="w-full flex items-center justify-center gap-1 py-1.5 bg-primary-foreground/20 text-primary-foreground font-body text-[10px] rounded-lg"><Eye className="w-3 h-3" /> View</a>
                      <button onClick={() => deleteMedia(m.id)} className="w-full flex items-center justify-center gap-1 py-1.5 bg-destructive text-destructive-foreground font-body text-[10px] rounded-lg"><Trash2 className="w-3 h-3" /> Delete</button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
          {media.length === 0 && pendingUploads.length === 0 && <p className="font-body text-xs text-muted-foreground text-center py-4">No media uploaded yet.</p>}
        </div>
      )}
    </div>
  );
};

/* ─────────────────────────────────────────────────────────────────────
   SOCIAL PLATFORM CONFIG
──────────────────────────────────────────────────────────────────────*/
const SOCIAL_PLATFORMS = [
  { key: "youtube",   label: "YouTube",   icon: Youtube,   color: "text-red-500",   placeholder: "https://youtube.com/@yourchanel" },
  { key: "facebook",  label: "Facebook",  icon: Facebook,  color: "text-blue-600",  placeholder: "https://facebook.com/yourpage" },
  { key: "instagram", label: "Instagram", icon: Instagram, color: "text-pink-500",  placeholder: "https://instagram.com/yourhandle" },
  { key: "tiktok",    label: "TikTok",    icon: Video,     color: "text-foreground",placeholder: "https://tiktok.com/@yourhandle" },
  { key: "twitter",   label: "X / Twitter", icon: Twitter, color: "text-foreground",placeholder: "https://x.com/yourhandle" },
  { key: "linkedin",  label: "LinkedIn",  icon: Linkedin,  color: "text-blue-500",  placeholder: "https://linkedin.com/company/yourcompany" },
  { key: "whatsapp",  label: "WhatsApp",  icon: Phone,     color: "text-green-500", placeholder: "https://wa.me/8801700000000" },
];

const CURRENCIES = [
  { code: "BDT", symbol: "৳", label: "Bangladeshi Taka" },
  { code: "AED", symbol: "د.إ", label: "UAE Dirham" },
  { code: "USD", symbol: "$", label: "US Dollar" },
  { code: "GBP", symbol: "£", label: "British Pound" },
  { code: "EUR", symbol: "€", label: "Euro" },
  { code: "SGD", symbol: "S$", label: "Singapore Dollar" },
];

/* ─────────────────────────────────────────────────────────────────────
   MAIN ADMIN COMPONENT
──────────────────────────────────────────────────────────────────────*/
const Admin = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = useState<AdminTab>("dashboard");
  const [session, setSession] = useState<any>(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const [checkingAuth, setCheckingAuth] = useState(true);
  const [showAddProperty, setShowAddProperty] = useState(false);
  const [editingProperty, setEditingProperty] = useState<any>(null);
  const [sidebarOpen, setSidebarOpen] = useState(true);

  const [propertyForm, setPropertyForm] = useState({
    title: "", description: "", address: "", city: "Dhaka", country: "Bangladesh",
    price: "", price_type: "sale", property_type: "apartment",
    bedrooms: "", bathrooms: "", area_sqft: "", is_featured: false, cover_image_url: "",
    is_installment: false, down_payment_pct: "20", installment_years: "5",
  });

  // Navbar management state
  const [newNavLink, setNewNavLink] = useState({ label: "", href: "", open_in_new_tab: false });
  const [editingLinkId, setEditingLinkId] = useState<string | null>(null);
  const [editLinkForm, setEditLinkForm] = useState({ label: "", href: "", open_in_new_tab: false });

  // Property view mode
  const [propertyView, setPropertyView] = useState<"grid" | "list">("grid");
  const [propertySearch, setPropertySearch] = useState("");
  const [propertyFilter, setPropertyFilter] = useState<"all" | "sale" | "rent" | "featured">("all");

  // Currency state
  const [selectedCurrency, setSelectedCurrency] = useState("BDT");
  const [selectedSymbol, setSelectedSymbol] = useState("৳");

  // Social integration state
  const [socialForms, setSocialForms] = useState<Record<string, { url: string; is_enabled: boolean }>>({});

  // General settings state
  const [generalSettings, setGeneralSettings] = useState<Record<string, string>>({});

  /* ── Auth Check ── */
  useEffect(() => {
    getSession().then((sess) => {
      setSession(sess);
      if (!sess) { navigate("/auth"); setCheckingAuth(false); return; }
      setIsAdmin(sess.isAdmin);
      setCheckingAuth(false);
    });
  }, [navigate]);

  /* ── Queries ── */
  const { data: properties = [] } = useQuery({
    queryKey: ["admin-properties"],
    queryFn: getAdminProperties,
    enabled: !!session && isAdmin,
  });

  const { data: inquiries = [] } = useQuery({
    queryKey: ["admin-inquiries"],
    queryFn: getAdminContactInquiries,
    enabled: !!session && isAdmin,
  });

  const { data: navbarLinks = [], refetch: refetchNav } = useQuery({
    queryKey: ["admin-navbar-links"],
    queryFn: getAdminNavbarLinks,
    enabled: !!session && isAdmin,
  });

  const { data: socialData = [], refetch: refetchSocial } = useQuery({
    queryKey: ["admin-social"],
    queryFn: getAdminSocialIntegrations,
    enabled: !!session && isAdmin,
    onSuccess: (data: any[]) => {
      const forms: Record<string, { url: string; is_enabled: boolean }> = {};
      data.forEach((s) => { forms[s.platform] = { url: s.url || "", is_enabled: s.is_enabled }; });
      setSocialForms(forms);
    },
  } as any);

  const { refetch: refetchSettings } = useQuery({
    queryKey: ["admin-site-settings"],
    queryFn: getSiteSettings,
    enabled: !!session && isAdmin,
    onSuccess: (data: any[]) => {
      const map: Record<string, string> = {};
      (data || []).forEach((s: any) => { map[s.key] = s.value || ""; });
      setGeneralSettings(map);
      if (map.currency) setSelectedCurrency(map.currency);
      if (map.currency_symbol) setSelectedSymbol(map.currency_symbol);
    },
  } as any);

  /* ── Mutations ── */
  const saveMutation = useMutation({
    mutationFn: async (values: typeof propertyForm) => {
      const payload = { title: values.title, description: values.description || null, address: values.address, city: values.city, country: values.country, price: Number(values.price), price_type: values.price_type, property_type: values.property_type, bedrooms: values.bedrooms ? Number(values.bedrooms) : null, bathrooms: values.bathrooms ? Number(values.bathrooms) : null, area_sqft: values.area_sqft ? Number(values.area_sqft) : null, is_featured: values.is_featured, cover_image_url: values.cover_image_url || null, is_installment: values.is_installment, down_payment_pct: Number(values.down_payment_pct), installment_years: Number(values.installment_years) };
      if (editingProperty) await updateProperty(editingProperty.id, payload);
      else await createProperty(payload);
    },
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ["admin-properties"] }); queryClient.invalidateQueries({ queryKey: ["featured-properties"] }); toast({ title: editingProperty ? "Property Updated!" : "Property Added!" }); setShowAddProperty(false); setEditingProperty(null); resetForm(); },
    onError: (err: any) => toast({ title: "Error", description: err.message, variant: "destructive" }),
  });

  const deleteMutation = useMutation({
    mutationFn: deleteProperty,
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ["admin-properties"] }); toast({ title: "Property Deleted" }); },
  });

  const markReadMutation = useMutation({
    mutationFn: markInquiryRead,
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["admin-inquiries"] }),
  });

  const saveSetting = async (key: string, value: string) => {
    await upsertSiteSetting(key, value);
    refetchSettings();
    queryClient.invalidateQueries({ queryKey: ["site-settings"] });
  };

  const saveCurrency = async () => {
    await upsertSiteSetting("currency", selectedCurrency);
    await upsertSiteSetting("currency_symbol", selectedSymbol);
    refetchSettings();
    queryClient.invalidateQueries({ queryKey: ["site-settings"] });
    toast({ title: "Currency saved!", description: `${selectedCurrency} (${selectedSymbol})` });
  };

  const saveSocialIntegration = async (platform: string) => {
    const form = socialForms[platform];
    if (!form) return;
    await upsertSocialIntegration({ platform, url: form.url, is_enabled: form.is_enabled });
    refetchSocial();
    queryClient.invalidateQueries({ queryKey: ["footer-socials"] });
    queryClient.invalidateQueries({ queryKey: ["whatsapp-integration"] });
    toast({ title: `${platform} saved!` });
  };

  const invalidatePublicNav = () => {
    queryClient.invalidateQueries({ queryKey: ["navbar-links"] });
  };

  const addNavLink = async () => {
    if (!newNavLink.label || !newNavLink.href) return;
    await createNavbarLink({ label: newNavLink.label, href: newNavLink.href });
    setNewNavLink({ label: "", href: "", open_in_new_tab: false });
    refetchNav();
    invalidatePublicNav();
    toast({ title: "Nav link added!" });
  };

  const saveEditLink = async () => {
    if (!editingLinkId) return;
    await updateNavbarLink(editingLinkId, { label: editLinkForm.label, href: editLinkForm.href });
    setEditingLinkId(null);
    refetchNav();
    invalidatePublicNav();
    toast({ title: "Link updated!" });
  };

  const moveNavLink = async (id: string, direction: "up" | "down") => {
    const links = [...(navbarLinks as any[])].sort((a, b) => a.display_order - b.display_order);
    const idx = links.findIndex((l) => l.id === id);
    const swapIdx = direction === "up" ? idx - 1 : idx + 1;
    if (swapIdx < 0 || swapIdx >= links.length) return;
    const a = links[idx], b = links[swapIdx];
    await reorderNavbarLinks(a.id, b.id);
    refetchNav();
    invalidatePublicNav();
  };

  const deleteNavLink = async (id: string) => {
    await deleteNavbarLink(id);
    refetchNav();
    invalidatePublicNav();
    toast({ title: "Nav link removed" });
  };

  const toggleNavLink = async (id: string, is_visible: boolean) => {
    await updateNavbarLink(id, { is_visible: !is_visible });
    refetchNav();
    invalidatePublicNav();
  };

  const resetForm = () => {
    setPropertyForm({ title: "", description: "", address: "", city: "Dhaka", country: "Bangladesh", price: "", price_type: "sale", property_type: "apartment", bedrooms: "", bathrooms: "", area_sqft: "", is_featured: false, cover_image_url: "", is_installment: false, down_payment_pct: "20", installment_years: "5" });
  };

  const startEdit = (property: any) => {
    setEditingProperty(property);
    setPropertyForm({ title: property.title, description: property.description || "", address: property.address, city: property.city, country: property.country, price: String(property.price), price_type: property.price_type, property_type: property.property_type, bedrooms: property.bedrooms ? String(property.bedrooms) : "", bathrooms: property.bathrooms ? String(property.bathrooms) : "", area_sqft: property.area_sqft ? String(property.area_sqft) : "", is_featured: property.is_featured, cover_image_url: property.cover_image_url || "", is_installment: property.is_installment ?? false, down_payment_pct: String(property.down_payment_pct ?? 20), installment_years: String(property.installment_years ?? 5) });
    setShowAddProperty(true);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const toggleFeatured = async (property: any) => {
    await setPropertyFeatured(property.id);
    queryClient.invalidateQueries({ queryKey: ["admin-properties"] });
  };

  const updateCoverFromMedia = async (propertyId: string, url: string) => {
    await setPropertyCover(propertyId, url);
    queryClient.invalidateQueries({ queryKey: ["admin-properties"] });
  };

  const handleLogout = async () => { await logout(); navigate("/"); };

  /* ── Loading / Auth Guard ── */
  if (checkingAuth) return (
    <div className="min-h-screen bg-background flex items-center justify-center">
      <div className="text-center"><div className="w-10 h-10 border-2 border-gold border-t-transparent rounded-full animate-spin mx-auto mb-4" /><p className="font-body text-muted-foreground text-sm">Loading...</p></div>
    </div>
  );

  if (!isAdmin) return (
    <div className="min-h-screen bg-background flex items-center justify-center px-4">
      <div className="text-center max-w-md">
        <div className="w-16 h-16 bg-destructive/10 rounded-full flex items-center justify-center mx-auto mb-4"><Settings className="w-7 h-7 text-destructive" /></div>
        <h2 className="font-display text-2xl font-bold text-foreground mb-2">Access Restricted</h2>
        <p className="font-body text-muted-foreground text-sm mb-6">You need admin privileges to access this page.</p>
        <button onClick={handleLogout} className="px-6 py-3 bg-primary text-primary-foreground font-body font-semibold text-sm rounded-lg">Sign Out</button>
      </div>
    </div>
  );

  const unreadCount = inquiries.filter((i: any) => !i.is_read).length;

  const NAV_ITEMS: { id: AdminTab; icon: any; label: string; badge?: number; group?: string }[] = [
    { id: "dashboard",    icon: LayoutDashboard, label: "Dashboard",     group: "Overview" },
    { id: "properties",   icon: Building2,       label: "Properties",    group: "Content" },
    { id: "inquiries",    icon: MessageSquare,   label: "Inquiries",     badge: unreadCount, group: "Content" },
    { id: "navbar",       icon: Menu,            label: "Navbar",        group: "Appearance" },
    { id: "currency",     icon: DollarSign,      label: "Currency",      group: "Appearance" },
    { id: "integrations", icon: Share2,          label: "Integrations",  group: "Appearance" },
    { id: "settings",     icon: Settings,        label: "Settings",      group: "System" },
  ];

  const inputCls = "w-full bg-background border border-border rounded-lg px-4 py-2.5 font-body text-sm outline-none focus:border-gold transition-colors";

  return (
    <div className="min-h-screen bg-background flex">

      {/* ── Sidebar ── */}
      <div className={`${sidebarOpen ? "w-64" : "w-16"} bg-primary fixed top-0 bottom-0 left-0 flex flex-col border-r border-gold/20 transition-all duration-300 z-40`}>
        {/* Logo */}
        <div className="p-4 border-b border-gold/20 flex items-center gap-3 min-h-[64px]">
          <div className="w-8 h-8 bg-gradient-gold rounded flex items-center justify-center shrink-0">
            <span className="font-display font-bold text-primary text-xs">SH</span>
          </div>
          {sidebarOpen && (
            <div className="flex-1 min-w-0">
              <div className="font-display font-semibold text-primary-foreground text-sm truncate">Skyline Holding</div>
              <div className="font-body text-gold text-xs">Admin Dashboard</div>
            </div>
          )}
          <button onClick={() => setSidebarOpen(!sidebarOpen)} className="ml-auto text-primary-foreground/50 hover:text-gold transition-colors shrink-0">
            <Menu className="w-4 h-4" />
          </button>
        </div>

        {/* Nav */}
        <nav className="flex-1 p-3 space-y-0.5 overflow-y-auto">
          {["Overview", "Content", "Appearance", "System"].map((group) => {
            const items = NAV_ITEMS.filter((i) => i.group === group);
            return (
              <div key={group} className="mb-4">
                {sidebarOpen && <p className="font-body text-[10px] uppercase tracking-widest text-primary-foreground/30 px-3 mb-1">{group}</p>}
                {items.map((item) => (
                  <button key={item.id} onClick={() => setActiveTab(item.id)}
                    className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg font-body text-sm transition-colors mb-0.5 ${activeTab === item.id ? "bg-gold text-primary font-semibold" : "text-primary-foreground/70 hover:text-primary-foreground hover:bg-primary-foreground/10"}`}
                    title={!sidebarOpen ? item.label : undefined}
                  >
                    <item.icon className="w-4 h-4 shrink-0" />
                    {sidebarOpen && <span className="truncate">{item.label}</span>}
                    {sidebarOpen && item.badge ? (
                      <span className="ml-auto bg-destructive text-destructive-foreground text-xs rounded-full w-5 h-5 flex items-center justify-center shrink-0">{item.badge}</span>
                    ) : null}
                    {!sidebarOpen && item.badge ? (
                      <span className="absolute left-8 top-0 w-2 h-2 bg-destructive rounded-full" />
                    ) : null}
                  </button>
                ))}
              </div>
            );
          })}
        </nav>

        {/* Footer */}
        <div className="p-3 border-t border-gold/20">
          {sidebarOpen && <div className="text-xs font-body text-primary-foreground/40 mb-2 px-3 truncate">{session?.email}</div>}
          <button onClick={handleLogout} className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg font-body text-sm text-primary-foreground/70 hover:text-destructive-foreground hover:bg-destructive/20 transition-colors" title={!sidebarOpen ? "Sign Out" : undefined}>
            <LogOut className="w-4 h-4 shrink-0" />
            {sidebarOpen && "Sign Out"}
          </button>
        </div>
      </div>

      {/* ── Main Content ── */}
      <div className={`${sidebarOpen ? "ml-64" : "ml-16"} flex-1 p-8 transition-all duration-300`}>

        {/* ══════════════════════════════════════════════════
            DASHBOARD
        ══════════════════════════════════════════════════ */}
        {activeTab === "dashboard" && (
          <div>
            <h1 className="font-display text-3xl font-bold text-foreground mb-8">Dashboard</h1>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
              {[
                { label: "Total Properties", value: properties.length, icon: Building2, color: "bg-primary" },
                { label: "Unread Inquiries", value: unreadCount, icon: MessageSquare, color: "bg-gold" },
                { label: "Featured", value: properties.filter((p: any) => p.is_featured).length, icon: Star, color: "bg-green-600" },
              ].map((stat) => (
                <div key={stat.label} className="bg-card rounded-xl shadow-card p-6 flex items-center gap-4">
                  <div className={`w-12 h-12 ${stat.color} rounded-xl flex items-center justify-center`}>
                    <stat.icon className="w-5 h-5 text-primary-foreground" />
                  </div>
                  <div>
                    <div className="font-display font-bold text-foreground text-3xl">{stat.value}</div>
                    <div className="font-body text-muted-foreground text-sm">{stat.label}</div>
                  </div>
                </div>
              ))}
            </div>

            {/* Quick links */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
              {[
                { id: "properties" as AdminTab,   icon: Building2,  label: "Manage Properties" },
                { id: "navbar" as AdminTab,        icon: Menu,       label: "Edit Navbar" },
                { id: "integrations" as AdminTab,  icon: Share2,     label: "Social Media" },
                { id: "settings" as AdminTab,      icon: Settings,   label: "Site Settings" },
              ].map((q) => (
                <button key={q.id} onClick={() => setActiveTab(q.id)} className="bg-card rounded-xl shadow-card p-4 flex flex-col items-start gap-2 hover:border-gold border border-border transition-colors text-left">
                  <q.icon className="w-5 h-5 text-gold" />
                  <span className="font-body text-sm font-medium text-foreground">{q.label}</span>
                </button>
              ))}
            </div>

            <div className="bg-card rounded-xl shadow-card p-6">
              <h2 className="font-display text-xl font-semibold text-foreground mb-4">Recent Inquiries</h2>
              {inquiries.slice(0, 5).length > 0 ? (
                <div className="space-y-3">
                  {inquiries.slice(0, 5).map((inq: any) => (
                    <div key={inq.id} className={`flex items-center gap-4 p-3 rounded-lg ${!inq.is_read ? "bg-gold/5 border border-gold/20" : "bg-muted/30"}`}>
                      <div className="flex-1 min-w-0">
                        <div className="font-body font-medium text-sm text-foreground">{inq.name}</div>
                        <div className="font-body text-xs text-muted-foreground truncate">{inq.message}</div>
                      </div>
                      {!inq.is_read && <span className="text-xs font-body bg-gold text-primary px-2 py-0.5 rounded shrink-0">New</span>}
                    </div>
                  ))}
                </div>
              ) : <p className="font-body text-muted-foreground text-sm">No inquiries yet.</p>}
            </div>
          </div>
        )}

        {/* ══════════════════════════════════════════════════
            PROPERTIES
        ══════════════════════════════════════════════════ */}
        {activeTab === "properties" && (() => {
          const filteredProperties = (properties as any[])
            .filter((p) => {
              const q = propertySearch.toLowerCase();
              const matchSearch = !q || p.title.toLowerCase().includes(q) || p.city.toLowerCase().includes(q) || p.country.toLowerCase().includes(q);
              const matchFilter =
                propertyFilter === "all" ? true :
                propertyFilter === "featured" ? p.is_featured :
                p.price_type === propertyFilter;
              return matchSearch && matchFilter;
            });

          return (
            <div className="animate-fade-in">
              {/* ── Page header ── */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
                <div>
                  <h1 className="font-display text-3xl font-bold text-foreground">Properties</h1>
                  <p className="font-body text-sm text-muted-foreground mt-1">{(properties as any[]).length} listings in total</p>
                </div>
                <button
                  onClick={() => { setShowAddProperty(true); setEditingProperty(null); resetForm(); }}
                  className="flex items-center gap-2 px-5 py-2.5 bg-gradient-gold text-primary font-body font-semibold text-sm rounded-xl shadow-gold hover:opacity-90 transition-opacity"
                >
                  <Plus className="w-4 h-4" />New Property
                </button>
              </div>

              {/* ── Filters + search + view toggle ── */}
              <div className="flex flex-col sm:flex-row gap-3 mb-6">
                {/* Search */}
                <div className="relative flex-1">
                  <Eye className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <input
                    value={propertySearch}
                    onChange={(e) => setPropertySearch(e.target.value)}
                    placeholder="Search by title, city, country…"
                    className="w-full bg-card border border-border rounded-xl pl-9 pr-4 py-2.5 font-body text-sm outline-none focus:border-gold transition-colors"
                  />
                </div>
                {/* Filter pills */}
                <div className="flex gap-1.5 bg-card border border-border rounded-xl p-1">
                  {(["all", "sale", "rent", "featured"] as const).map((f) => (
                    <button
                      key={f}
                      onClick={() => setPropertyFilter(f)}
                      className={`px-3 py-1.5 rounded-lg font-body text-xs font-medium capitalize transition-all ${propertyFilter === f ? "bg-gradient-gold text-primary shadow-gold" : "text-muted-foreground hover:text-foreground"}`}
                    >
                      {f === "all" ? "All" : f === "featured" ? "★ Featured" : f.charAt(0).toUpperCase() + f.slice(1)}
                    </button>
                  ))}
                </div>
                {/* View toggle */}
                <div className="flex gap-1 bg-card border border-border rounded-xl p-1">
                  <button onClick={() => setPropertyView("grid")} className={`p-2 rounded-lg transition-colors ${propertyView === "grid" ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground"}`} title="Grid view">
                    <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 16 16"><rect x="1" y="1" width="6" height="6" rx="1"/><rect x="9" y="1" width="6" height="6" rx="1"/><rect x="1" y="9" width="6" height="6" rx="1"/><rect x="9" y="9" width="6" height="6" rx="1"/></svg>
                  </button>
                  <button onClick={() => setPropertyView("list")} className={`p-2 rounded-lg transition-colors ${propertyView === "list" ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground"}`} title="List view">
                    <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 16 16"><rect x="1" y="2" width="14" height="2.5" rx="1"/><rect x="1" y="6.75" width="14" height="2.5" rx="1"/><rect x="1" y="11.5" width="14" height="2.5" rx="1"/></svg>
                  </button>
                </div>
              </div>

              {/* ── Slide-in Add / Edit form ── */}
              {showAddProperty && (
                <div className="fixed inset-0 z-50 flex">
                  {/* Backdrop */}
                  <div className="flex-1 bg-foreground/40 backdrop-blur-sm" onClick={() => { setShowAddProperty(false); setEditingProperty(null); }} />
                  {/* Panel */}
                  <div className="w-full max-w-2xl bg-card shadow-2xl flex flex-col animate-slide-in-right overflow-hidden">
                    {/* Panel header */}
                    <div className="flex items-center justify-between px-8 py-5 border-b border-border bg-primary">
                      <div>
                        <h2 className="font-display text-xl font-bold text-primary-foreground">{editingProperty ? "Edit Property" : "Add New Property"}</h2>
                        <p className="font-body text-xs text-primary-foreground/60 mt-0.5">{editingProperty ? `Editing: ${editingProperty.title}` : "Fill in the details below"}</p>
                      </div>
                      <button onClick={() => { setShowAddProperty(false); setEditingProperty(null); }} className="w-9 h-9 flex items-center justify-center rounded-full text-primary-foreground/60 hover:text-primary-foreground hover:bg-primary-foreground/10 transition-colors">
                        <X className="w-5 h-5" />
                      </button>
                    </div>

                    {/* Scrollable form body */}
                    <div className="flex-1 overflow-y-auto px-8 py-6">
                      <form id="property-form" onSubmit={(e) => { e.preventDefault(); saveMutation.mutate(propertyForm); }} className="space-y-5">
                        {/* Section: Basic Info */}
                        <div>
                          <p className="font-body text-[10px] uppercase tracking-widest text-gold font-semibold mb-3">Basic Information</p>
                          <div className="space-y-3">
                            <div>
                              <label className="font-body text-xs text-muted-foreground font-medium block mb-1.5">Property Title *</label>
                              <input required value={propertyForm.title} onChange={(e) => setPropertyForm((p) => ({ ...p, title: e.target.value }))} placeholder="e.g. Sky Residence Penthouse" className={inputCls} />
                            </div>
                            <div>
                              <label className="font-body text-xs text-muted-foreground font-medium block mb-1.5">Description</label>
                              <textarea value={propertyForm.description} onChange={(e) => setPropertyForm((p) => ({ ...p, description: e.target.value }))} rows={4} placeholder="Describe the property in detail…" className={`${inputCls} resize-none`} />
                            </div>
                          </div>
                        </div>

                        {/* Section: Location */}
                        <div>
                          <p className="font-body text-[10px] uppercase tracking-widest text-gold font-semibold mb-3">Location</p>
                          <div className="space-y-3">
                            <div>
                              <label className="font-body text-xs text-muted-foreground font-medium block mb-1.5">Street Address *</label>
                              <input required value={propertyForm.address} onChange={(e) => setPropertyForm((p) => ({ ...p, address: e.target.value }))} placeholder="Street address…" className={inputCls} />
                            </div>
                            <div className="grid grid-cols-2 gap-3">
                              <div>
                                <label className="font-body text-xs text-muted-foreground font-medium block mb-1.5">City</label>
                                <input value={propertyForm.city} onChange={(e) => setPropertyForm((p) => ({ ...p, city: e.target.value }))} className={inputCls} />
                              </div>
                              <div>
                                <label className="font-body text-xs text-muted-foreground font-medium block mb-1.5">Country</label>
                                <select value={propertyForm.country} onChange={(e) => setPropertyForm((p) => ({ ...p, country: e.target.value }))} className={inputCls}>
                                  <option value="Bangladesh">Bangladesh</option>
                                  <option value="UAE">UAE (Dubai)</option>
                                </select>
                              </div>
                            </div>
                          </div>
                        </div>

                        {/* Section: Pricing */}
                        <div>
                          <p className="font-body text-[10px] uppercase tracking-widest text-gold font-semibold mb-3">Pricing & Type</p>
                          <div className="grid grid-cols-2 gap-3">
                            <div>
                              <label className="font-body text-xs text-muted-foreground font-medium block mb-1.5">Price *</label>
                              <input required type="number" value={propertyForm.price} onChange={(e) => setPropertyForm((p) => ({ ...p, price: e.target.value }))} placeholder="0" className={inputCls} />
                            </div>
                            <div>
                              <label className="font-body text-xs text-muted-foreground font-medium block mb-1.5">Listing Type</label>
                              <select value={propertyForm.price_type} onChange={(e) => setPropertyForm((p) => ({ ...p, price_type: e.target.value }))} className={inputCls}>
                                <option value="sale">For Sale</option>
                                <option value="rent">For Rent</option>
                              </select>
                            </div>
                            <div className="col-span-2">
                              <label className="font-body text-xs text-muted-foreground font-medium block mb-1.5">Property Type</label>
                              <div className="grid grid-cols-3 gap-2">
                                {["apartment","villa","office","commercial","land","penthouse"].map((t) => (
                                  <button
                                    key={t} type="button"
                                    onClick={() => setPropertyForm((p) => ({ ...p, property_type: t }))}
                                    className={`py-2 rounded-lg font-body text-xs font-medium border transition-all ${propertyForm.property_type === t ? "border-gold bg-gold/10 text-gold" : "border-border text-muted-foreground hover:border-gold/40"}`}
                                  >
                                    {t.charAt(0).toUpperCase() + t.slice(1)}
                                  </button>
                                ))}
                              </div>
                            </div>
                          </div>
                        </div>

                        {/* Section: Details */}
                        <div>
                          <p className="font-body text-[10px] uppercase tracking-widest text-gold font-semibold mb-3">Property Details</p>
                          <div className="grid grid-cols-3 gap-3">
                            <div>
                              <label className="font-body text-xs text-muted-foreground font-medium block mb-1.5">Bedrooms</label>
                              <input type="number" value={propertyForm.bedrooms} onChange={(e) => setPropertyForm((p) => ({ ...p, bedrooms: e.target.value }))} placeholder="—" className={inputCls} />
                            </div>
                            <div>
                              <label className="font-body text-xs text-muted-foreground font-medium block mb-1.5">Bathrooms</label>
                              <input type="number" value={propertyForm.bathrooms} onChange={(e) => setPropertyForm((p) => ({ ...p, bathrooms: e.target.value }))} placeholder="—" className={inputCls} />
                            </div>
                            <div>
                              <label className="font-body text-xs text-muted-foreground font-medium block mb-1.5">Area (sqft)</label>
                              <input type="number" value={propertyForm.area_sqft} onChange={(e) => setPropertyForm((p) => ({ ...p, area_sqft: e.target.value }))} placeholder="—" className={inputCls} />
                            </div>
                          </div>
                        </div>

                        {/* Section: Media */}
                        <div>
                          <p className="font-body text-[10px] uppercase tracking-widest text-gold font-semibold mb-3">Cover Image</p>
                          <input value={propertyForm.cover_image_url} onChange={(e) => setPropertyForm((p) => ({ ...p, cover_image_url: e.target.value }))} placeholder="https://... or set from gallery" className={inputCls} />
                          {propertyForm.cover_image_url && (
                            <div className="mt-3 h-32 rounded-xl overflow-hidden border border-border">
                              <img src={propertyForm.cover_image_url} alt="Cover preview" className="w-full h-full object-cover" />
                            </div>
                          )}
                        </div>

                        {/* Featured toggle */}
                        <div className="flex items-center justify-between p-4 bg-gold/5 border border-gold/20 rounded-xl">
                          <div>
                            <div className="font-body font-medium text-foreground text-sm">Featured Property</div>
                            <div className="font-body text-xs text-muted-foreground">Show on the homepage featured section</div>
                          </div>
                          <button
                            type="button"
                            onClick={() => setPropertyForm((p) => ({ ...p, is_featured: !p.is_featured }))}
                            className={`relative w-12 h-6 rounded-full transition-colors ${propertyForm.is_featured ? "bg-gold" : "bg-muted-foreground/30"}`}
                          >
                            <span className={`absolute top-1 w-4 h-4 rounded-full bg-white shadow transition-all ${propertyForm.is_featured ? "left-7" : "left-1"}`} />
                          </button>
                        </div>

                        {/* Installment section */}
                        <div className="border border-border rounded-xl overflow-hidden">
                          {/* Toggle header */}
                          <div className="flex items-center justify-between p-4 bg-muted/20">
                            <div>
                              <div className="font-body font-medium text-foreground text-sm">💳 Installment Payment</div>
                              <div className="font-body text-xs text-muted-foreground">Allow buyers to pay in installments</div>
                            </div>
                            <button
                              type="button"
                              onClick={() => setPropertyForm((p) => ({ ...p, is_installment: !p.is_installment }))}
                              className={`relative w-12 h-6 rounded-full transition-colors ${propertyForm.is_installment ? "bg-gold" : "bg-muted-foreground/30"}`}
                            >
                              <span className={`absolute top-1 w-4 h-4 rounded-full bg-white shadow transition-all ${propertyForm.is_installment ? "left-7" : "left-1"}`} />
                            </button>
                          </div>

                          {/* Installment options (visible when enabled) */}
                          {propertyForm.is_installment && (
                            <div className="p-4 space-y-4 bg-gold/3 border-t border-border">
                              <div>
                                <label className="font-body text-xs text-muted-foreground font-medium block mb-1.5">
                                  Down Payment % <span className="text-gold font-bold ml-1">{propertyForm.down_payment_pct}%</span>
                                </label>
                                <div className="flex items-center gap-3">
                                  <input
                                    type="range" min={5} max={50} step={5}
                                    value={propertyForm.down_payment_pct}
                                    onChange={(e) => setPropertyForm((p) => ({ ...p, down_payment_pct: e.target.value }))}
                                    className="flex-1 accent-gold cursor-pointer"
                                  />
                                  <input
                                    type="number" min={5} max={50}
                                    value={propertyForm.down_payment_pct}
                                    onChange={(e) => setPropertyForm((p) => ({ ...p, down_payment_pct: e.target.value }))}
                                    className="w-16 text-center bg-background border border-border rounded-lg px-2 py-1.5 font-body text-sm outline-none focus:border-gold"
                                  />
                                </div>
                                {propertyForm.price && (
                                  <p className="font-body text-xs text-muted-foreground mt-1">
                                    Down payment: <span className="text-gold font-semibold">{Math.round(Number(propertyForm.price) * Number(propertyForm.down_payment_pct) / 100).toLocaleString()}</span>
                                  </p>
                                )}
                              </div>

                              <div>
                                <label className="font-body text-xs text-muted-foreground font-medium block mb-1.5">Installment Tenure (Years)</label>
                                <div className="grid grid-cols-6 gap-2">
                                  {[3, 5, 7, 10, 15, 20].map((y) => (
                                    <button
                                      key={y} type="button"
                                      onClick={() => setPropertyForm((p) => ({ ...p, installment_years: String(y) }))}
                                      className={`py-1.5 rounded-lg font-body text-xs font-medium transition-all ${
                                        String(y) === propertyForm.installment_years
                                          ? "bg-gradient-gold text-primary shadow-gold"
                                          : "bg-muted text-muted-foreground hover:bg-gold/10 hover:text-gold"
                                      }`}
                                    >
                                      {y}yr
                                    </button>
                                  ))}
                                </div>
                              </div>

                              {/* Live preview */}
                              {propertyForm.price && (
                                <div className="grid grid-cols-3 gap-3 pt-2">
                                  {(() => {
                                    const p = Number(propertyForm.price);
                                    const down = p * Number(propertyForm.down_payment_pct) / 100;
                                    const rem = p - down;
                                    const yrs = Number(propertyForm.installment_years);
                                    return [
                                      { label: "Monthly", amount: rem / (yrs * 12) },
                                      { label: "Quarterly", amount: rem / (yrs * 4) },
                                      { label: "6-Monthly", amount: rem / (yrs * 2) },
                                    ].map(({ label, amount }) => (
                                      <div key={label} className="bg-background border border-border rounded-lg p-3 text-center">
                                        <div className="font-body text-[10px] text-muted-foreground mb-1">{label}</div>
                                        <div className="font-display font-bold text-foreground text-sm">{Math.round(amount).toLocaleString()}</div>
                                      </div>
                                    ));
                                  })()}
                                </div>
                              )}
                            </div>
                          )}
                        </div>

                        {/* Media manager for existing property */}
                        {editingProperty && (
                          <MediaManager
                            propertyId={editingProperty.id}
                            onCoverSet={(url) => { setPropertyForm((p) => ({ ...p, cover_image_url: url })); updateCoverFromMedia(editingProperty.id, url); }}
                          />
                        )}
                      </form>
                    </div>

                    {/* Panel footer */}
                    <div className="px-8 py-5 border-t border-border flex gap-3">
                      <button form="property-form" type="submit" disabled={saveMutation.isPending} className="flex-1 py-3 bg-gradient-gold text-primary font-body font-semibold text-sm rounded-xl shadow-gold hover:opacity-90 transition-opacity disabled:opacity-60">
                        {saveMutation.isPending ? "Saving…" : editingProperty ? "Update Property" : "Add Property"}
                      </button>
                      <button type="button" onClick={() => { setShowAddProperty(false); setEditingProperty(null); }} className="px-6 py-3 bg-muted text-muted-foreground font-body font-semibold text-sm rounded-xl hover:bg-muted/80 transition-colors">
                        Cancel
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {/* ── GRID view ── */}
              {propertyView === "grid" && (
                <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-5">
                  {filteredProperties.map((property: any) => (
                    <div key={property.id} className="group bg-card rounded-2xl border border-border hover:border-gold/40 shadow-card hover:shadow-gold transition-all duration-300 overflow-hidden flex flex-col">
                      {/* Image */}
                      <div className="relative h-44 overflow-hidden bg-muted shrink-0">
                        {property.cover_image_url
                          ? <img src={property.cover_image_url} alt={property.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                          : <div className="w-full h-full flex items-center justify-center"><Building2 className="w-10 h-10 text-muted-foreground/40" /></div>
                        }
                        {/* Overlay badges */}
                        <div className="absolute top-3 left-3 flex gap-2">
                          <span className={`font-body text-[10px] font-bold uppercase tracking-wider px-2.5 py-1 rounded-full ${property.price_type === "rent" ? "bg-blue-600 text-white" : "bg-gold text-primary"}`}>
                            {property.price_type === "rent" ? "For Rent" : "For Sale"}
                          </span>
                          {property.is_featured && (
                            <span className="font-body text-[10px] font-bold uppercase tracking-wider px-2.5 py-1 rounded-full bg-primary text-primary-foreground">
                              ★ Featured
                            </span>
                          )}
                        </div>
                        {/* Action overlay */}
                        <div className="absolute inset-0 bg-primary/70 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-3">
                          <button onClick={() => startEdit(property)} className="w-10 h-10 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center text-white hover:bg-gold hover:text-primary transition-colors" title="Edit">
                            <Edit2 className="w-4 h-4" />
                          </button>
                          <button onClick={() => toggleFeatured(property)} className={`w-10 h-10 backdrop-blur-sm rounded-full flex items-center justify-center transition-colors ${property.is_featured ? "bg-gold text-primary" : "bg-white/20 text-white hover:bg-gold hover:text-primary"}`} title="Toggle featured">
                            <Star className="w-4 h-4" />
                          </button>
                          <button onClick={() => { if (confirm("Delete this property?")) deleteMutation.mutate(property.id); }} className="w-10 h-10 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center text-white hover:bg-destructive hover:text-white transition-colors" title="Delete">
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>

                      {/* Content */}
                      <div className="p-4 flex-1 flex flex-col">
                        <h3 className="font-display font-semibold text-foreground text-base leading-tight mb-1 line-clamp-1">{property.title}</h3>
                        <p className="font-body text-xs text-muted-foreground mb-3">{property.city}, {property.country}</p>

                        {/* Stats row */}
                        <div className="flex items-center gap-3 text-xs font-body text-muted-foreground mb-4">
                          {property.bedrooms != null && <span className="flex items-center gap-1">🛏 {property.bedrooms} bd</span>}
                          {property.bathrooms != null && <span className="flex items-center gap-1">🚿 {property.bathrooms} ba</span>}
                          {property.area_sqft && <span className="flex items-center gap-1">📐 {Number(property.area_sqft).toLocaleString()} sqft</span>}
                        </div>

                        <div className="mt-auto flex items-center justify-between">
                          <div>
                            <div className="font-display font-bold text-foreground text-lg">
                              {generalSettings["currency_symbol"] || "৳"}{Number(property.price).toLocaleString()}
                            </div>
                            <div className="font-body text-[10px] text-muted-foreground capitalize">{property.property_type}</div>
                          </div>
                          <button onClick={() => startEdit(property)} className="flex items-center gap-1.5 px-3 py-1.5 bg-muted rounded-lg text-xs font-body font-medium text-muted-foreground hover:bg-gold/10 hover:text-gold transition-colors">
                            <Edit2 className="w-3 h-3" />Edit
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}

                  {/* Add card */}
                  <button
                    onClick={() => { setShowAddProperty(true); setEditingProperty(null); resetForm(); }}
                    className="border-2 border-dashed border-border hover:border-gold/50 rounded-2xl h-full min-h-[280px] flex flex-col items-center justify-center gap-3 text-muted-foreground hover:text-gold transition-all group"
                  >
                    <div className="w-14 h-14 rounded-full border-2 border-dashed border-current flex items-center justify-center group-hover:scale-110 transition-transform">
                      <Plus className="w-6 h-6" />
                    </div>
                    <span className="font-body text-sm font-medium">Add Property</span>
                  </button>
                </div>
              )}

              {/* ── LIST view ── */}
              {propertyView === "list" && (
                <div className="space-y-3">
                  {filteredProperties.map((property: any) => (
                    <div key={property.id} className="group bg-card rounded-xl border border-border hover:border-gold/30 shadow-card transition-all flex items-center gap-5 p-4 overflow-hidden">
                      {/* Thumbnail */}
                      <div className="w-20 h-16 shrink-0 rounded-xl overflow-hidden bg-muted border border-border">
                        {property.cover_image_url
                          ? <img src={property.cover_image_url} alt={property.title} className="w-full h-full object-cover" />
                          : <div className="w-full h-full flex items-center justify-center"><Building2 className="w-5 h-5 text-muted-foreground/40" /></div>
                        }
                      </div>

                      {/* Main info */}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-0.5">
                          <h3 className="font-display font-semibold text-foreground text-sm truncate">{property.title}</h3>
                          {property.is_featured && <span className="shrink-0 text-[10px] bg-gold/20 text-gold px-1.5 py-0.5 rounded font-body font-semibold">★ Featured</span>}
                        </div>
                        <p className="font-body text-xs text-muted-foreground">{property.city}, {property.country} · <span className="capitalize">{property.property_type}</span></p>
                      </div>

                      {/* Price */}
                      <div className="hidden sm:block text-right shrink-0">
                        <div className="font-display font-bold text-foreground">{generalSettings["currency_symbol"] || "৳"}{Number(property.price).toLocaleString()}</div>
                        <div className={`text-[10px] font-body font-semibold px-2 py-0.5 rounded-full mt-1 inline-block ${property.price_type === "rent" ? "bg-blue-100 text-blue-700" : "bg-gold/15 text-gold"}`}>
                          {property.price_type === "rent" ? "For Rent" : "For Sale"}
                        </div>
                      </div>

                      {/* Actions */}
                      <div className="flex items-center gap-1.5 shrink-0">
                        <button onClick={() => toggleFeatured(property)} className={`p-2 rounded-lg transition-colors ${property.is_featured ? "bg-gold/20 text-gold" : "text-muted-foreground hover:text-gold hover:bg-gold/10"}`}><Star className="w-4 h-4" /></button>
                        <button onClick={() => startEdit(property)} className="p-2 rounded-lg text-muted-foreground hover:text-foreground hover:bg-muted transition-colors"><Edit2 className="w-4 h-4" /></button>
                        <button onClick={() => { if (confirm("Delete this property?")) deleteMutation.mutate(property.id); }} className="p-2 rounded-lg text-muted-foreground hover:text-destructive hover:bg-destructive/10 transition-colors"><Trash2 className="w-4 h-4" /></button>
                      </div>
                    </div>
                  ))}
                  {filteredProperties.length === 0 && (
                    <div className="bg-card rounded-xl shadow-card p-12 text-center">
                      <Building2 className="w-10 h-10 text-muted-foreground/30 mx-auto mb-3" />
                      <p className="font-body text-muted-foreground text-sm">No properties match your search.</p>
                    </div>
                  )}
                </div>
              )}

              {filteredProperties.length === 0 && propertyView === "grid" && (properties as any[]).length > 0 && (
                <div className="col-span-full text-center py-12 text-muted-foreground font-body text-sm">No properties match your filters.</div>
              )}
            </div>
          );
        })()}


        {/* ══════════════════════════════════════════════════
            INQUIRIES
        ══════════════════════════════════════════════════ */}
        {activeTab === "inquiries" && (
          <div>
            <h1 className="font-display text-3xl font-bold text-foreground mb-8">Inquiries</h1>
            <div className="space-y-4">
              {inquiries.map((inq: any) => (
                <div key={inq.id} className={`bg-card rounded-xl shadow-card p-6 ${!inq.is_read ? "border border-gold/30" : "border border-border"}`}>
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-3 mb-2">
                        <span className="font-display font-semibold text-foreground">{inq.name}</span>
                        {!inq.is_read && <span className="text-xs bg-gold text-primary font-body font-semibold px-2 py-0.5 rounded">New</span>}
                      </div>
                      <div className="font-body text-xs text-muted-foreground mb-1">{inq.email}{inq.phone && ` • ${inq.phone}`}</div>
                      {inq.properties?.title && <div className="font-body text-xs text-gold mb-2">Re: {inq.properties.title}</div>}
                      <p className="font-body text-sm text-foreground/80">{inq.message}</p>
                      <div className="font-body text-xs text-muted-foreground mt-2">{new Date(inq.created_at).toLocaleDateString()}</div>
                    </div>
                    {!inq.is_read && (
                      <button onClick={() => markReadMutation.mutate(inq.id)} className="flex items-center gap-1.5 px-3 py-1.5 bg-muted rounded-lg font-body text-xs text-muted-foreground hover:text-foreground transition-colors shrink-0">
                        <Check className="w-3.5 h-3.5" />Mark Read
                      </button>
                    )}
                  </div>
                </div>
              ))}
              {inquiries.length === 0 && <div className="bg-card rounded-xl shadow-card p-12 text-center"><MessageSquare className="w-10 h-10 text-muted-foreground mx-auto mb-3" /><p className="font-body text-muted-foreground">No inquiries yet.</p></div>}
            </div>
          </div>
        )}

        {/* ══════════════════════════════════════════════════
            NAVBAR MANAGEMENT
        ══════════════════════════════════════════════════ */}
        {activeTab === "navbar" && (
          <div>
            <div className="mb-8">
              <h1 className="font-display text-3xl font-bold text-foreground">Navbar Management</h1>
              <p className="font-body text-muted-foreground text-sm mt-1">Control all navigation links, appearance options, and header buttons.</p>
            </div>

            {/* ── Live Links ── */}
            <div className="bg-card rounded-xl shadow-card p-6 mb-6">
              <h2 className="font-display text-lg font-semibold text-foreground mb-1">Navigation Links</h2>
              <p className="font-body text-xs text-muted-foreground mb-5">Reorder, edit, show/hide or delete each nav link. Changes reflect on the live site instantly.</p>
              <div className="space-y-3">
                {(navbarLinks as any[]).sort((a, b) => a.display_order - b.display_order).map((link: any, idx: number, arr: any[]) => (
                  <div key={link.id}>
                    {/* View row */}
                    {editingLinkId !== link.id ? (
                      <div className={`flex items-center gap-3 p-4 rounded-xl border transition-all ${link.is_visible ? "bg-muted/30 border-border" : "bg-muted/10 border-dashed border-border opacity-60"}`}>
                        {/* Reorder */}
                        <div className="flex flex-col gap-0.5 shrink-0">
                          <button onClick={() => moveNavLink(link.id, "up")} disabled={idx === 0} className="p-0.5 text-muted-foreground hover:text-foreground disabled:opacity-20 transition-colors"><ChevronUp className="w-3.5 h-3.5" /></button>
                          <button onClick={() => moveNavLink(link.id, "down")} disabled={idx === arr.length - 1} className="p-0.5 text-muted-foreground hover:text-foreground disabled:opacity-20 transition-colors"><ChevronDown className="w-3.5 h-3.5" /></button>
                        </div>
                        {/* Order badge */}
                        <span className="w-6 h-6 rounded-full bg-muted text-muted-foreground flex items-center justify-center font-body text-xs font-semibold shrink-0">{idx + 1}</span>
                        {/* Info */}
                        <div className="flex-1 min-w-0">
                          <div className="font-body font-semibold text-foreground text-sm">{link.label}</div>
                          <div className="font-body text-xs text-muted-foreground">{link.href}</div>
                        </div>
                        {/* Actions */}
                        <button
                          onClick={() => toggleNavLink(link.id, link.is_visible)}
                          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-body text-xs font-medium transition-all ${link.is_visible ? "bg-green-100 text-green-700 hover:bg-green-200" : "bg-muted text-muted-foreground hover:bg-muted/80"}`}
                        >
                          {link.is_visible ? <><ToggleRight className="w-3.5 h-3.5" />Visible</> : <><ToggleLeft className="w-3.5 h-3.5" />Hidden</>}
                        </button>
                        <button
                          onClick={() => { setEditingLinkId(link.id); setEditLinkForm({ label: link.label, href: link.href, open_in_new_tab: false }); }}
                          className="p-2 rounded-lg text-muted-foreground hover:text-foreground hover:bg-muted transition-colors"
                        ><Edit2 className="w-4 h-4" /></button>
                        <button onClick={() => deleteNavLink(link.id)} className="p-2 rounded-lg text-muted-foreground hover:text-destructive hover:bg-destructive/10 transition-colors"><Trash2 className="w-4 h-4" /></button>
                      </div>
                    ) : (
                      /* Edit row */
                      <div className="p-4 rounded-xl border-2 border-gold/40 bg-gold/5 space-y-3">
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                          <div>
                            <label className="font-body text-xs text-muted-foreground font-medium uppercase tracking-wide block mb-1">Label</label>
                            <input value={editLinkForm.label} onChange={(e) => setEditLinkForm((p) => ({ ...p, label: e.target.value }))} className={inputCls} />
                          </div>
                          <div>
                            <label className="font-body text-xs text-muted-foreground font-medium uppercase tracking-wide block mb-1">URL / Path</label>
                            <input value={editLinkForm.href} onChange={(e) => setEditLinkForm((p) => ({ ...p, href: e.target.value }))} className={inputCls} />
                          </div>
                        </div>
                        <div className="flex gap-2">
                          <button onClick={saveEditLink} className="flex items-center gap-1.5 px-4 py-2 bg-gradient-gold text-primary font-body text-xs font-semibold rounded-lg shadow-gold hover:opacity-90"><Save className="w-3.5 h-3.5" />Save</button>
                          <button onClick={() => setEditingLinkId(null)} className="px-4 py-2 bg-muted text-muted-foreground font-body text-xs rounded-lg hover:bg-muted/80 transition-colors">Cancel</button>
                        </div>
                      </div>
                    )}
                  </div>
                ))}
                {(navbarLinks as any[]).length === 0 && (
                  <div className="text-center py-8 text-muted-foreground font-body text-sm">No links yet — add one below.</div>
                )}
              </div>
            </div>

            {/* ── Add New Link ── */}
            <div className="bg-card rounded-xl shadow-card p-6 mb-6">
              <h2 className="font-display text-lg font-semibold text-foreground mb-4 flex items-center gap-2">
                <Plus className="w-5 h-5 text-gold" />Add New Link
              </h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-4">
                <div>
                  <label className="font-body text-xs text-muted-foreground font-medium uppercase tracking-wide block mb-1.5">Label</label>
                  <input value={newNavLink.label} onChange={(e) => setNewNavLink((p) => ({ ...p, label: e.target.value }))} placeholder="e.g. About Us" className={inputCls} />
                </div>
                <div>
                  <label className="font-body text-xs text-muted-foreground font-medium uppercase tracking-wide block mb-1.5">URL / Path</label>
                  <input value={newNavLink.href} onChange={(e) => setNewNavLink((p) => ({ ...p, href: e.target.value }))} placeholder="e.g. /about or https://..." className={inputCls} />
                </div>
              </div>
              <button onClick={addNavLink} className="flex items-center gap-2 px-5 py-2.5 bg-gradient-gold text-primary font-body font-semibold text-sm rounded-lg shadow-gold hover:opacity-90 transition-opacity">
                <Plus className="w-4 h-4" />Add Link
              </button>
            </div>

            {/* ── Navbar Options ── */}
            <div className="bg-card rounded-xl shadow-card p-6 mb-6">
              <h2 className="font-display text-lg font-semibold text-foreground mb-1 flex items-center gap-2">
                <Phone className="w-5 h-5 text-gold" />Header Phone Number
              </h2>
              <p className="font-body text-xs text-muted-foreground mb-4">Shown next to the nav buttons on desktop. Leave blank to hide.</p>
              <div className="flex gap-2 max-w-md">
                <input
                  value={generalSettings["navbar_phone"] || ""}
                  onChange={(e) => setGeneralSettings((p) => ({ ...p, navbar_phone: e.target.value }))}
                  placeholder="+880 170 000 0000"
                  className={`${inputCls} flex-1`}
                />
                <button onClick={() => saveSetting("navbar_phone", generalSettings["navbar_phone"] || "")} className="px-4 py-2 bg-gradient-gold text-primary font-body text-xs font-semibold rounded-lg shadow-gold hover:opacity-90 shrink-0"><Save className="w-4 h-4" /></button>
              </div>
            </div>

            {/* ── Navbar Button Visibility ── */}
            <div className="bg-card rounded-xl shadow-card p-6">
              <h2 className="font-display text-lg font-semibold text-foreground mb-1 flex items-center gap-2">
                <Settings className="w-5 h-5 text-gold" />Header Buttons
              </h2>
              <p className="font-body text-xs text-muted-foreground mb-5">Control which buttons appear in the top-right of the navbar.</p>
              <div className="space-y-4">
                {[
                  { key: "navbar_show_login", label: "Customer Login Button", description: "Shows the 'Login' button for customers" },
                  { key: "navbar_show_admin", label: "Admin Button", description: "Shows the 'Admin' quick-access button" },
                ].map((opt) => {
                  const enabled = generalSettings[opt.key] !== "false";
                  return (
                    <div key={opt.key} className="flex items-center justify-between p-4 bg-muted/30 rounded-xl border border-border">
                      <div>
                        <div className="font-body font-medium text-foreground text-sm">{opt.label}</div>
                        <div className="font-body text-xs text-muted-foreground">{opt.description}</div>
                      </div>
                      <button
                        onClick={async () => {
                          const newVal = enabled ? "false" : "true";
                          setGeneralSettings((p) => ({ ...p, [opt.key]: newVal }));
                          await saveSetting(opt.key, newVal);
                          toast({ title: `${opt.label} ${newVal === "true" ? "enabled" : "disabled"}` });
                        }}
                        className={`relative w-12 h-6 rounded-full transition-colors shrink-0 ${enabled ? "bg-gold" : "bg-muted-foreground/30"}`}
                      >
                        <span className={`absolute top-1 w-4 h-4 rounded-full bg-white shadow transition-all ${enabled ? "left-7" : "left-1"}`} />
                      </button>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {/* ══════════════════════════════════════════════════
            CURRENCY
        ══════════════════════════════════════════════════ */}
        {activeTab === "currency" && (
          <div>
            <div className="mb-8">
              <h1 className="font-display text-3xl font-bold text-foreground">Currency Settings</h1>
              <p className="font-body text-muted-foreground text-sm mt-1">Set the default currency displayed across the site for property prices.</p>
            </div>

            <div className="bg-card rounded-xl shadow-card p-6 max-w-2xl">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
                {CURRENCIES.map((c) => (
                  <button key={c.code} onClick={() => { setSelectedCurrency(c.code); setSelectedSymbol(c.symbol); }}
                    className={`flex items-center gap-4 p-4 rounded-xl border-2 transition-all text-left ${selectedCurrency === c.code ? "border-gold bg-gold/5" : "border-border hover:border-gold/40"}`}
                  >
                    <div className={`w-12 h-12 rounded-xl flex items-center justify-center font-display font-bold text-lg ${selectedCurrency === c.code ? "bg-gradient-gold text-primary shadow-gold" : "bg-muted text-muted-foreground"}`}>
                      {c.symbol}
                    </div>
                    <div>
                      <div className="font-body font-semibold text-foreground text-sm">{c.code}</div>
                      <div className="font-body text-xs text-muted-foreground">{c.label}</div>
                    </div>
                    {selectedCurrency === c.code && <Check className="w-4 h-4 text-gold ml-auto" />}
                  </button>
                ))}
              </div>

              <div className="flex items-center gap-3 p-4 bg-gold/5 border border-gold/20 rounded-xl mb-6">
                <DollarSign className="w-5 h-5 text-gold" />
                <span className="font-body text-sm text-foreground">Selected: <strong>{selectedCurrency}</strong> ({selectedSymbol})</span>
              </div>

              <button onClick={saveCurrency} className="flex items-center gap-2 px-6 py-2.5 bg-gradient-gold text-primary font-body font-semibold text-sm rounded-lg shadow-gold hover:opacity-90 transition-opacity">
                <Save className="w-4 h-4" />Save Currency
              </button>
            </div>
          </div>
        )}

        {/* ══════════════════════════════════════════════════
            SOCIAL INTEGRATIONS
        ══════════════════════════════════════════════════ */}
        {activeTab === "integrations" && (
          <div>
            <div className="mb-8">
              <h1 className="font-display text-3xl font-bold text-foreground">Social Media Integrations</h1>
              <p className="font-body text-muted-foreground text-sm mt-1">Add your social media profile URLs and toggle their visibility in the site footer.</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              {SOCIAL_PLATFORMS.map((platform) => {
                const Icon = platform.icon;
                const form = socialForms[platform.key] || { url: "", is_enabled: false };
                return (
                  <div key={platform.key} className={`bg-card rounded-xl shadow-card p-5 border-2 transition-all ${form.is_enabled ? "border-gold/30" : "border-border"}`}>
                    <div className="flex items-center gap-3 mb-4">
                      <div className={`w-10 h-10 rounded-xl bg-muted flex items-center justify-center`}>
                        <Icon className={`w-5 h-5 ${platform.color}`} />
                      </div>
                      <div className="flex-1">
                        <div className="font-body font-semibold text-foreground text-sm">{platform.label}</div>
                        <div className={`font-body text-xs ${form.is_enabled ? "text-green-600" : "text-muted-foreground"}`}>
                          {form.is_enabled ? "Active" : "Inactive"}
                        </div>
                      </div>
                      <button
                        onClick={() => setSocialForms((p) => ({ ...p, [platform.key]: { ...form, is_enabled: !form.is_enabled } }))}
                        className={`relative w-11 h-6 rounded-full transition-colors ${form.is_enabled ? "bg-gold" : "bg-muted"}`}
                      >
                        <span className={`absolute top-1 w-4 h-4 rounded-full bg-white shadow transition-all ${form.is_enabled ? "left-6" : "left-1"}`} />
                      </button>
                    </div>
                    <div className="flex gap-2">
                      <div className="relative flex-1">
                        <LinkIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
                        <input
                          value={form.url}
                          onChange={(e) => setSocialForms((p) => ({ ...p, [platform.key]: { ...form, url: e.target.value } }))}
                          placeholder={platform.placeholder}
                          className="w-full bg-background border border-border rounded-lg pl-9 pr-3 py-2 font-body text-xs outline-none focus:border-gold transition-colors"
                        />
                      </div>
                      <button onClick={() => saveSocialIntegration(platform.key)} className="px-3 py-2 bg-gradient-gold text-primary font-body text-xs font-semibold rounded-lg shadow-gold hover:opacity-90 transition-opacity shrink-0">
                        Save
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* ══════════════════════════════════════════════════
            SETTINGS
        ══════════════════════════════════════════════════ */}
        {activeTab === "settings" && (
          <div>
            <div className="mb-8">
              <h1 className="font-display text-3xl font-bold text-foreground">Site Settings</h1>
              <p className="font-body text-muted-foreground text-sm mt-1">Manage general site information, contact details, and office addresses.</p>
            </div>

            <div className="space-y-6 max-w-2xl">
              {/* Site Identity */}
              <div className="bg-card rounded-xl shadow-card p-6">
                <h2 className="font-display text-lg font-semibold text-foreground mb-4 flex items-center gap-2">
                  <Globe className="w-5 h-5 text-gold" />Site Identity
                </h2>
                <div className="space-y-4">
                  {[
                    { key: "site_title", label: "Site Title", placeholder: "Skyline Holding Ltd" },
                    { key: "site_tagline", label: "Tagline", placeholder: "Premium Real Estate..." },
                  ].map((field) => (
                    <div key={field.key}>
                      <label className="font-body text-xs text-muted-foreground font-medium uppercase tracking-wide block mb-1.5">{field.label}</label>
                      <div className="flex gap-2">
                        <input value={generalSettings[field.key] || ""} onChange={(e) => setGeneralSettings((p) => ({ ...p, [field.key]: e.target.value }))} placeholder={field.placeholder} className={`${inputCls} flex-1`} />
                        <button onClick={() => saveSetting(field.key, generalSettings[field.key] || "")} className="px-3 py-2 bg-gradient-gold text-primary font-body text-xs font-semibold rounded-lg shadow-gold hover:opacity-90 shrink-0"><Save className="w-4 h-4" /></button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Contact Details */}
              <div className="bg-card rounded-xl shadow-card p-6">
                <h2 className="font-display text-lg font-semibold text-foreground mb-4 flex items-center gap-2">
                  <Phone className="w-5 h-5 text-gold" />Contact Details
                </h2>
                <div className="space-y-4">
                  {[
                    { key: "phone_bd", label: "Phone — Bangladesh", placeholder: "+880 170 000 0000" },
                    { key: "phone_dubai", label: "Phone — Dubai", placeholder: "+971 4 000 0000" },
                    { key: "email", label: "Email Address", placeholder: "info@skylineholding.com" },
                  ].map((field) => (
                    <div key={field.key}>
                      <label className="font-body text-xs text-muted-foreground font-medium uppercase tracking-wide block mb-1.5">{field.label}</label>
                      <div className="flex gap-2">
                        <input value={generalSettings[field.key] || ""} onChange={(e) => setGeneralSettings((p) => ({ ...p, [field.key]: e.target.value }))} placeholder={field.placeholder} className={`${inputCls} flex-1`} />
                        <button onClick={() => saveSetting(field.key, generalSettings[field.key] || "")} className="px-3 py-2 bg-gradient-gold text-primary font-body text-xs font-semibold rounded-lg shadow-gold hover:opacity-90 shrink-0"><Save className="w-4 h-4" /></button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Office Addresses */}
              <div className="bg-card rounded-xl shadow-card p-6">
                <h2 className="font-display text-lg font-semibold text-foreground mb-4 flex items-center gap-2">
                  <Building2 className="w-5 h-5 text-gold" />Office Addresses
                </h2>
                <div className="space-y-4">
                  {[
                    { key: "address_bd", label: "Bangladesh Office", placeholder: "Gulshan 2, Dhaka 1212, Bangladesh" },
                    { key: "address_dubai", label: "Dubai Office", placeholder: "Downtown Dubai, UAE" },
                  ].map((field) => (
                    <div key={field.key}>
                      <label className="font-body text-xs text-muted-foreground font-medium uppercase tracking-wide block mb-1.5">{field.label}</label>
                      <div className="flex gap-2">
                        <input value={generalSettings[field.key] || ""} onChange={(e) => setGeneralSettings((p) => ({ ...p, [field.key]: e.target.value }))} placeholder={field.placeholder} className={`${inputCls} flex-1`} />
                        <button onClick={() => saveSetting(field.key, generalSettings[field.key] || "")} className="px-3 py-2 bg-gradient-gold text-primary font-body text-xs font-semibold rounded-lg shadow-gold hover:opacity-90 shrink-0"><Save className="w-4 h-4" /></button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Info note */}
              <div className="flex items-start gap-3 p-4 bg-muted/50 rounded-xl border border-border">
                <AlertCircle className="w-4 h-4 text-muted-foreground shrink-0 mt-0.5" />
                <p className="font-body text-xs text-muted-foreground">Changes are saved individually per field. Click the <Save className="w-3 h-3 inline" /> icon next to each field to save.</p>
              </div>
            </div>
          </div>
        )}

      </div>
    </div>
  );
};

export default Admin;
