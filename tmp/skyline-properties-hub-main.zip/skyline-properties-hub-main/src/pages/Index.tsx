import heroImg from "@/assets/hero-bg.jpg";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import PropertyCard from "@/components/PropertyCard";
import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Search, MapPin, ChevronRight, Building2, Home, DollarSign, Users, ArrowRight } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { getFeaturedProperties, getPropertyStats } from "@/lib/api";

const Index = () => {
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState("");
  const [searchType, setSearchType] = useState("all");

  const { data: featuredProperties = [] } = useQuery({
    queryKey: ["featured-properties"],
    queryFn: getFeaturedProperties,
  });

  const { data: stats } = useQuery({
    queryKey: ["property-stats"],
    queryFn: getPropertyStats,
  });

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    const params = new URLSearchParams();
    if (searchQuery) params.set("q", searchQuery);
    if (searchType !== "all") params.set("type", searchType);
    navigate(`/properties?${params.toString()}`);
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center">
        <div
          className="absolute inset-0 bg-cover bg-center bg-no-repeat"
          style={{ backgroundImage: `url(${heroImg})` }}
        />
        <div className="absolute inset-0 bg-gradient-to-r from-primary/90 via-primary/70 to-primary/30" />

        <div className="relative container mx-auto px-4 pt-20">
          <div className="max-w-3xl">
            <div className="flex items-center gap-2 mb-6 animate-fade-in">
              <div className="h-px w-12 bg-gold" />
              <span className="font-body text-gold text-sm font-medium tracking-widest uppercase">
                Bangladesh & Dubai
              </span>
            </div>

            <h1 className="font-display text-5xl md:text-6xl lg:text-7xl font-bold text-primary-foreground leading-tight mb-6 animate-fade-up">
              Find Your{" "}
              <span className="text-gold">Dream</span>
              <br />
              Property
            </h1>

            <p className="font-body text-primary-foreground/80 text-lg md:text-xl mb-10 leading-relaxed max-w-xl animate-fade-up" style={{ animationDelay: "0.1s" }}>
              Premium properties for sale and rent across Dhaka, Chittagong, and Dubai. 
              Trusted by hundreds of families.
            </p>

            {/* Search Box */}
            <div className="bg-card rounded-xl p-4 shadow-gold animate-fade-up transition-smooth hover:shadow-lg" style={{ animationDelay: "0.2s" }}>
              <div className="flex gap-2 mb-3">
                {[
                  { value: "all", label: "All" },
                  { value: "sale", label: "Buy" },
                  { value: "rent", label: "Rent" },
                ].map((tab) => (
                  <button
                    key={tab.value}
                    onClick={() => setSearchType(tab.value)}
                    className={`px-4 py-2 rounded font-body text-sm font-medium transition-all duration-200 ${
                      searchType === tab.value
                        ? "bg-primary text-primary-foreground"
                        : "text-muted-foreground hover:text-foreground"
                    }`}
                  >
                    {tab.label}
                  </button>
                ))}
              </div>

              <form onSubmit={handleSearch} className="flex gap-3">
                <div className="flex-1 flex items-center gap-3 bg-background rounded-lg px-4 border border-border focus-within:border-gold/50 focus-within:ring-2 focus-within:ring-gold/20 transition-all duration-200">
                  <Search className="w-4 h-4 text-muted-foreground shrink-0" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Search by city, location, or property type..."
                    className="flex-1 py-3 bg-transparent font-body text-sm text-foreground placeholder:text-muted-foreground outline-none"
                  />
                </div>
                <button
                  type="submit"
                  className="px-6 py-3 bg-gradient-gold text-primary font-body font-semibold text-sm rounded-lg shadow-gold hover:opacity-90 hover:shadow-lg transition-all duration-200 flex items-center gap-2 whitespace-nowrap"
                >
                  <Search className="w-4 h-4" />
                  Search
                </button>
              </form>
            </div>

            {/* Quick filters */}
            <div className="flex flex-wrap gap-3 mt-4 animate-fade-up" style={{ animationDelay: "0.3s" }}>
              {["Dhaka", "Chittagong", "Dubai", "Apartment", "Villa"].map((tag) => (
                <button
                  key={tag}
                  onClick={() => {
                    setSearchQuery(tag);
                    navigate(`/properties?q=${tag}`);
                  }}
                  className="px-3 py-1.5 bg-primary-foreground/10 hover:bg-gold/20 text-primary-foreground/80 hover:text-gold border border-primary-foreground/20 hover:border-gold/50 rounded-full font-body text-xs transition-all duration-200"
                >
                  {tag}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Scroll hint */}
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 text-primary-foreground/50">
          <span className="font-body text-xs">Scroll to explore</span>
          <div className="w-px h-8 bg-primary-foreground/30 animate-pulse" />
        </div>
      </section>

      {/* Stats Bar */}
      <section className="bg-primary py-8 border-b border-gold/20">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            {[
              { icon: Building2, label: "Total Properties", value: stats?.total || 0 },
              { icon: Home, label: "For Sale", value: stats?.forSale || 0 },
              { icon: DollarSign, label: "For Rent", value: stats?.forRent || 0 },
              { icon: MapPin, label: "Cities", value: "5+" },
            ].map((stat) => (
              <div key={stat.label} className="transition-transform duration-200 hover:scale-105">
                <stat.icon className="w-6 h-6 text-gold mx-auto mb-2" />
                <div className="font-display font-bold text-primary-foreground text-2xl">
                  {stat.value}
                </div>
                <div className="font-body text-primary-foreground/60 text-xs mt-1">
                  {stat.label}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Properties */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="flex items-end justify-between mb-12">
            <div>
              <div className="flex items-center gap-2 mb-3">
                <div className="h-px w-8 bg-gold" />
                <span className="font-body text-gold text-sm font-medium tracking-widest uppercase">
                  Curated Selection
                </span>
              </div>
              <h2 className="font-display text-4xl font-bold text-foreground">
                Featured Properties
              </h2>
            </div>
            <Link
              to="/properties"
              className="hidden md:flex items-center gap-2 font-body text-sm font-medium text-gold hover:gap-3 transition-all duration-200"
            >
              View All <ArrowRight className="w-4 h-4" />
            </Link>
          </div>

          {featuredProperties.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {featuredProperties.map((property, i) => (
                <div key={property.id} className="animate-fade-up" style={{ animationDelay: `${0.1 * i}s` }}>
                  <PropertyCard property={property} />
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-20">
              <div className="w-20 h-20 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
                <Building2 className="w-8 h-8 text-muted-foreground" />
              </div>
              <h3 className="font-display text-xl text-foreground mb-2">Properties Coming Soon</h3>
              <p className="font-body text-muted-foreground text-sm">
                Our admin will be adding premium properties shortly.
              </p>
            </div>
          )}

          <div className="text-center mt-10 md:hidden">
            <Link
              to="/properties"
              className="inline-flex items-center gap-2 px-6 py-3 bg-primary text-primary-foreground font-body font-semibold text-sm rounded-lg hover:bg-primary/90 transition-colors duration-200"
            >
              View All Properties <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-20 bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="text-center mb-14">
            <div className="flex items-center justify-center gap-2 mb-3">
              <div className="h-px w-8 bg-gold" />
              <span className="font-body text-gold text-sm font-medium tracking-widest uppercase">
                Why Skyline
              </span>
              <div className="h-px w-8 bg-gold" />
            </div>
            <h2 className="font-display text-4xl font-bold text-foreground">
              Your Trusted Property Partner
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                icon: "🏆",
                title: "Premium Listings",
                desc: "Handpicked properties in prime locations across Bangladesh and Dubai, verified for quality.",
              },
              {
                icon: "🤝",
                title: "Expert Guidance",
                desc: "Our experienced team provides full support from property search to final handover.",
              },
              {
                icon: "🔒",
                title: "Safe & Transparent",
                desc: "Complete transparency in pricing, legal documentation, and transaction process.",
              },
            ].map((item) => (
              <div key={item.title} className="bg-card rounded-xl p-8 shadow-card text-center transition-all duration-300 hover:shadow-lg hover:-translate-y-1">
                <div className="text-4xl mb-4">{item.icon}</div>
                <h3 className="font-display text-xl font-semibold text-foreground mb-3">
                  {item.title}
                </h3>
                <p className="font-body text-muted-foreground text-sm leading-relaxed">
                  {item.desc}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Banner */}
      <section className="py-20 bg-primary relative overflow-hidden">
        <div className="absolute inset-0 opacity-5">
          <div className="absolute top-0 right-0 w-96 h-96 rounded-full bg-gold blur-3xl" />
        </div>
        <div className="container mx-auto px-4 text-center relative">
          <h2 className="font-display text-4xl md:text-5xl font-bold text-primary-foreground mb-4">
            Ready to Find Your{" "}
            <span className="text-gold">Perfect Property?</span>
          </h2>
          <p className="font-body text-primary-foreground/70 text-lg mb-8 max-w-xl mx-auto">
            Contact us today and let our experts guide you to the property of your dreams.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              to="/contact"
              className="px-8 py-4 bg-gradient-gold text-primary font-body font-semibold rounded-lg shadow-gold hover:opacity-90 hover:shadow-lg transition-all duration-200"
            >
              Contact Us
            </Link>
            <Link
              to="/properties"
              className="px-8 py-4 bg-primary-foreground/10 text-primary-foreground border border-primary-foreground/20 font-body font-semibold rounded-lg hover:bg-primary-foreground/20 transition-all duration-200"
            >
              Browse Properties
            </Link>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default Index;
