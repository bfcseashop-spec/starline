const path = require("path");
require("dotenv").config({ path: path.resolve(__dirname, ".env") });
process.chdir(__dirname);
require("./dist/index.cjs");
