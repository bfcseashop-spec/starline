import "dotenv/config";
import express, { type Request, Response, NextFunction } from "express";
import session from "express-session";
import connectPgSimple from "connect-pg-simple";
import { registerRoutes } from "./routes";
import { serveStatic } from "./static";
import { createServer } from "http";
import { pool } from "./db";

const app = express();
const httpServer = createServer(app);

const PgStore = connectPgSimple(session);
const isProduction = process.env.NODE_ENV === "production";
const sessionSecret = process.env.SESSION_SECRET || "skyline-fallback-secret-change-me";

if (isProduction && !process.env.SESSION_SECRET) {
  console.warn(
    "[session] SESSION_SECRET is not set in .env. Set it to a fixed value so login sessions survive deployments."
  );
}

app.set("trust proxy", true);
app.use(express.json({ limit: "10mb" }));
app.use(express.urlencoded({ extended: false }));

app.use(
  session({
    store: new PgStore({
      pool,
      createTableIfMissing: true,
      tableName: "session",
    }),
    secret: sessionSecret,
    resave: false,
    saveUninitialized: false,
    name: "connect.sid",
    proxy: isProduction,
    cookie: {
      path: "/",
      secure: isProduction,
      httpOnly: true,
      maxAge: 24 * 60 * 60 * 1000,
      sameSite: "lax",
    },
  })
);

(async () => {
  try {
    const { seedDatabase } = await import("./seed");
    await seedDatabase();
  } catch (err: any) {
    console.error("Seed error:", err?.message);
  }

  await registerRoutes(app);

  app.use((err: any, _req: Request, res: Response, _next: NextFunction) => {
    const status = err.status ?? 500;
    const message = err.message || "Internal Server Error";
    console.error("Error:", err);
    if (!res.headersSent) res.status(status).json({ message });
  });

  if (process.env.NODE_ENV === "production") {
    serveStatic(app);
  }

  const port = parseInt(process.env.PORT || "5011", 10);
  httpServer.listen(port, "0.0.0.0", () => {
    console.log(`Skyline Properties Hub serving on port ${port}`);
  });
})();
