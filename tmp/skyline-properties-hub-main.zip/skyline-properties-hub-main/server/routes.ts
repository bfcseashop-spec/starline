import express, { type Express } from "express";
import path from "path";
import fs from "fs";
import bcrypt from "bcryptjs";
import multer from "multer";
import { eq, and, desc, asc, sql, or, gte, lte } from "drizzle-orm";
import { db } from "./db";
import {
  users,
  userRoles,
  properties,
  propertyMedia,
  contactInquiries,
  siteSettings,
  navbarLinks,
  socialIntegrations,
} from "../shared/schema";

declare module "express-session" {
  interface SessionData {
    userId: string;
    email: string;
    fullName: string | null;
    isAdmin: boolean;
  }
}

const uploadsDir = path.join(process.cwd(), "uploads", "property-media");
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true });
}

const propertyMediaUpload = multer({
  storage: multer.diskStorage({
    destination: (_req, _file, cb) => cb(null, uploadsDir),
    filename: (_req, file, cb) => {
      const ext = (file.originalname.split(".").pop() || "jpg").toLowerCase();
      const name = `${Date.now()}-${Math.random().toString(36).slice(2)}.${ext}`;
      cb(null, name);
    },
  }),
  fileFilter: (_req, file, cb) => {
    const ok =
      file.mimetype.startsWith("image/") || file.mimetype.startsWith("video/");
    if (ok) cb(null, true);
    else cb(new Error("Only images and videos allowed"));
  },
  limits: { fileSize: 50 * 1024 * 1024 },
});

function requireAuth(
  req: express.Request,
  res: express.Response,
  next: express.NextFunction
) {
  if (!req.session?.userId) {
    return res.status(401).json({ message: "Not authenticated" });
  }
  next();
}

function requireAdmin(
  req: express.Request,
  res: express.Response,
  next: express.NextFunction
) {
  if (!req.session?.userId) {
    return res.status(401).json({ message: "Not authenticated" });
  }
  if (!req.session?.isAdmin) {
    return res.status(403).json({ message: "Admin access required" });
  }
  next();
}

export async function registerRoutes(app: Express) {
  // Serve uploaded files (URLs stored as /uploads/property-media/...)
  const uploadsRoot = path.join(process.cwd(), "uploads");
  app.use("/uploads", express.static(uploadsRoot));

  // ----- Auth -----
  app.post("/api/auth/login", async (req, res) => {
    try {
      const { email, password, adminOnly } = req.body;
      if (!email || !password) {
        return res.status(400).json({ message: "Email and password are required" });
      }
      const [user] = await db.select().from(users).where(eq(users.email, email));
      if (!user) {
        return res.status(401).json({ message: "Invalid email or password" });
      }
      const ok = await bcrypt.compare(password, user.password);
      if (!ok) {
        return res.status(401).json({ message: "Invalid email or password" });
      }
      const [roleRow] = await db
        .select()
        .from(userRoles)
        .where(and(eq(userRoles.user_id, user.id), eq(userRoles.role, "admin")));
      const isAdmin = !!roleRow;
      if (adminOnly && !isAdmin) {
        return res.status(403).json({ message: "Access denied. You do not have admin privileges." });
      }
      req.session.userId = user.id;
      req.session.email = user.email;
      req.session.fullName = user.full_name ?? null;
      req.session.isAdmin = isAdmin;
      req.session.save((err) => {
        if (err) {
          console.error("Session save error:", err);
          return res.status(500).json({ message: "Session error" });
        }
        res.json({
          user: {
            id: user.id,
            email: user.email,
            full_name: user.full_name,
            isAdmin,
          },
        });
      });
    } catch (e: any) {
      res.status(500).json({ message: e?.message || "Login failed" });
    }
  });

  app.post("/api/auth/logout", (req, res) => {
    req.session.destroy((err) => {
      if (err) return res.status(500).json({ message: "Logout failed" });
      res.clearCookie("connect.sid", { path: "/", httpOnly: true, sameSite: "lax" });
      res.json({ message: "Logged out" });
    });
  });

  app.post("/api/auth/signup", async (req, res) => {
    try {
      const { email, password, full_name } = req.body;
      if (!email || !password) {
        return res.status(400).json({ message: "Email and password are required" });
      }
      const [existing] = await db.select().from(users).where(eq(users.email, email));
      if (existing) {
        return res.status(400).json({ message: "An account with this email already exists" });
      }
      const hash = await bcrypt.hash(password, 10);
      const [user] = await db
        .insert(users)
        .values({ email, password: hash, full_name: full_name || null })
        .returning();
      if (!user) throw new Error("Insert failed");
      await db.insert(userRoles).values({ user_id: user.id, role: "user" });
      req.session.userId = user.id;
      req.session.email = user.email;
      req.session.fullName = user.full_name ?? null;
      req.session.isAdmin = false;
      req.session.save((err) => {
        if (err) return res.status(500).json({ message: "Session error" });
        res.status(201).json({ user: { id: user.id, email: user.email, full_name: user.full_name, isAdmin: false } });
      });
    } catch (e: any) {
      res.status(500).json({ message: e?.message || "Signup failed" });
    }
  });

  app.get("/api/auth/me", (req, res) => {
    if (!req.session?.userId) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    res.json({
      id: req.session.userId,
      email: req.session.email,
      full_name: req.session.fullName,
      isAdmin: req.session.isAdmin,
    });
  });

  // ----- Public: Properties -----
  app.get("/api/properties", async (req, res) => {
    try {
      const q = (req.query.q as string) || "";
      const type = req.query.type as string; // sale | rent | all
      const propertyType = req.query.propertyType as string;
      const city = req.query.city as string;
      const country = req.query.country as string;
      const minPrice = req.query.minPrice as string;
      const maxPrice = req.query.maxPrice as string;
      const bedrooms = req.query.bedrooms as string;

      let query = db.select().from(properties).orderBy(desc(properties.is_featured), desc(properties.created_at));

      // Apply filters in app (simpler than dynamic drizzle builder here)
      const rows = await query;
      let filtered = rows;
      if (q) {
        const lower = q.toLowerCase();
        filtered = filtered.filter(
          (r) =>
            (r.title && r.title.toLowerCase().includes(lower)) ||
            (r.address && r.address.toLowerCase().includes(lower)) ||
            (r.city && r.city.toLowerCase().includes(lower)) ||
            (r.description && r.description.toLowerCase().includes(lower))
        );
      }
      if (type && type !== "all") filtered = filtered.filter((r) => r.price_type === type);
      if (propertyType && propertyType !== "all") filtered = filtered.filter((r) => r.property_type === propertyType);
      if (city && city !== "all") filtered = filtered.filter((r) => r.city === city);
      if (country && country !== "all") filtered = filtered.filter((r) => r.country === country);
      if (minPrice) filtered = filtered.filter((r) => Number(r.price) >= Number(minPrice));
      if (maxPrice) filtered = filtered.filter((r) => Number(r.price) <= Number(maxPrice));
      if (bedrooms && bedrooms !== "all") filtered = filtered.filter((r) => (r.bedrooms ?? 0) >= Number(bedrooms));

      res.json(filtered);
    } catch (e: any) {
      res.status(500).json({ message: e?.message || "Failed to fetch properties" });
    }
  });

  app.get("/api/properties/featured", async (_req, res) => {
    try {
      const rows = await db
        .select()
        .from(properties)
        .where(and(eq(properties.is_featured, true), eq(properties.status, "available")))
        .orderBy(desc(properties.created_at))
        .limit(6);
      res.json(rows);
    } catch (e: any) {
      res.status(500).json({ message: e?.message || "Failed" });
    }
  });

  app.get("/api/properties/stats", async (_req, res) => {
    try {
      const all = await db.select().from(properties);
      const total = all.length;
      const forSale = all.filter((r) => r.price_type === "sale").length;
      const forRent = all.filter((r) => r.price_type === "rent").length;
      res.json({ total, forSale, forRent });
    } catch (e: any) {
      res.status(500).json({ message: e?.message || "Failed" });
    }
  });

  app.get("/api/properties/:id", async (req, res) => {
    try {
      const [row] = await db.select().from(properties).where(eq(properties.id, req.params.id));
      if (!row) return res.status(404).json({ message: "Property not found" });
      res.json(row);
    } catch (e: any) {
      res.status(500).json({ message: e?.message || "Failed" });
    }
  });

  app.get("/api/properties/:id/media", async (req, res) => {
    try {
      const rows = await db
        .select()
        .from(propertyMedia)
        .where(eq(propertyMedia.property_id, req.params.id))
        .orderBy(asc(propertyMedia.display_order));
      res.json(rows);
    } catch (e: any) {
      res.status(500).json({ message: e?.message || "Failed" });
    }
  });

  // ----- Public: Contact -----
  app.post("/api/contact-inquiries", async (req, res) => {
    try {
      const { property_id, name, email, phone, message } = req.body;
      if (!name || !email || !message) {
        return res.status(400).json({ message: "Name, email and message are required" });
      }
      await db.insert(contactInquiries).values({
        property_id: property_id || null,
        name,
        email,
        phone: phone || null,
        message,
      });
      res.status(201).json({ message: "Submitted" });
    } catch (e: any) {
      res.status(500).json({ message: e?.message || "Failed to submit" });
    }
  });

  // ----- Public: Site settings, navbar, social -----
  app.get("/api/site-settings", async (_req, res) => {
    try {
      const rows = await db.select().from(siteSettings);
      res.json(rows);
    } catch (e: any) {
      res.status(500).json({ message: e?.message || "Failed" });
    }
  });

  app.get("/api/navbar-links", async (_req, res) => {
    try {
      const rows = await db
        .select()
        .from(navbarLinks)
        .where(eq(navbarLinks.is_visible, true))
        .orderBy(asc(navbarLinks.display_order));
      res.json(rows);
    } catch (e: any) {
      res.status(500).json({ message: e?.message || "Failed" });
    }
  });

  app.get("/api/social-integrations", async (_req, res) => {
    try {
      const rows = await db.select().from(socialIntegrations);
      res.json(rows);
    } catch (e: any) {
      res.status(500).json({ message: e?.message || "Failed" });
    }
  });

  app.get("/api/social-integrations/whatsapp", async (_req, res) => {
    try {
      const [row] = await db
        .select()
        .from(socialIntegrations)
        .where(eq(socialIntegrations.platform, "whatsapp"));
      res.json(row || null);
    } catch (e: any) {
      res.status(500).json({ message: e?.message || "Failed" });
    }
  });

  // ----- Admin: Properties -----
  app.get("/api/admin/properties", requireAdmin, async (_req, res) => {
    try {
      const rows = await db.select().from(properties).orderBy(desc(properties.created_at));
      res.json(rows);
    } catch (e: any) {
      res.status(500).json({ message: e?.message || "Failed" });
    }
  });

  app.post("/api/admin/properties", requireAdmin, async (req, res) => {
    try {
      const body = req.body;
      const [row] = await db
        .insert(properties)
        .values({
          title: body.title,
          description: body.description ?? null,
          address: body.address,
          city: body.city ?? "Dhaka",
          country: body.country ?? "Bangladesh",
          price: String(body.price),
          price_type: body.price_type ?? "sale",
          property_type: body.property_type ?? "apartment",
          bedrooms: body.bedrooms ?? null,
          bathrooms: body.bathrooms ?? null,
          area_sqft: body.area_sqft ?? null,
          is_featured: body.is_featured ?? false,
          status: body.status ?? "available",
          cover_image_url: body.cover_image_url ?? null,
          is_installment: body.is_installment ?? false,
          down_payment_pct: body.down_payment_pct ?? "20",
          installment_years: body.installment_years ?? 5,
        })
        .returning();
      res.status(201).json(row);
    } catch (e: any) {
      res.status(500).json({ message: e?.message || "Failed" });
    }
  });

  app.patch("/api/admin/properties/:id", requireAdmin, async (req, res) => {
    try {
      const body = req.body;
      const [row] = await db
        .update(properties)
        .set({
          ...(body.title !== undefined && { title: body.title }),
          ...(body.description !== undefined && { description: body.description }),
          ...(body.address !== undefined && { address: body.address }),
          ...(body.city !== undefined && { city: body.city }),
          ...(body.country !== undefined && { country: body.country }),
          ...(body.price !== undefined && { price: String(body.price) }),
          ...(body.price_type !== undefined && { price_type: body.price_type }),
          ...(body.property_type !== undefined && { property_type: body.property_type }),
          ...(body.bedrooms !== undefined && { bedrooms: body.bedrooms }),
          ...(body.bathrooms !== undefined && { bathrooms: body.bathrooms }),
          ...(body.area_sqft !== undefined && { area_sqft: body.area_sqft }),
          ...(body.is_featured !== undefined && { is_featured: body.is_featured }),
          ...(body.status !== undefined && { status: body.status }),
          ...(body.cover_image_url !== undefined && { cover_image_url: body.cover_image_url }),
          ...(body.is_installment !== undefined && { is_installment: body.is_installment }),
          ...(body.down_payment_pct !== undefined && { down_payment_pct: String(body.down_payment_pct) }),
          ...(body.installment_years !== undefined && { installment_years: body.installment_years }),
          updated_at: new Date(),
        })
        .where(eq(properties.id, req.params.id))
        .returning();
      if (!row) return res.status(404).json({ message: "Not found" });
      res.json(row);
    } catch (e: any) {
      res.status(500).json({ message: e?.message || "Failed" });
    }
  });

  app.delete("/api/admin/properties/:id", requireAdmin, async (req, res) => {
    try {
      await db.delete(properties).where(eq(properties.id, req.params.id));
      res.status(204).send();
    } catch (e: any) {
      res.status(500).json({ message: e?.message || "Failed" });
    }
  });

  app.patch("/api/admin/properties/:id/featured", requireAdmin, async (req, res) => {
    try {
      const [p] = await db.select().from(properties).where(eq(properties.id, req.params.id));
      if (!p) return res.status(404).json({ message: "Not found" });
      const [row] = await db
        .update(properties)
        .set({ is_featured: !p.is_featured, updated_at: new Date() })
        .where(eq(properties.id, req.params.id))
        .returning();
      res.json(row);
    } catch (e: any) {
      res.status(500).json({ message: e?.message || "Failed" });
    }
  });

  app.patch("/api/admin/properties/:id/cover", requireAdmin, async (req, res) => {
    try {
      const { url } = req.body;
      if (!url) return res.status(400).json({ message: "url required" });
      const [row] = await db
        .update(properties)
        .set({ cover_image_url: url, updated_at: new Date() })
        .where(eq(properties.id, req.params.id))
        .returning();
      if (!row) return res.status(404).json({ message: "Not found" });
      res.json(row);
    } catch (e: any) {
      res.status(500).json({ message: e?.message || "Failed" });
    }
  });

  // ----- Admin: Property media (upload) -----
  app.post(
    "/api/admin/properties/:id/media",
    requireAdmin,
    propertyMediaUpload.single("file"),
    async (req, res) => {
      try {
        if (!req.file) return res.status(400).json({ message: "No file" });
        const propertyId = req.params.id;
        const relativePath = `/uploads/property-media/${req.file.filename}`;
        const mediaType = req.file.mimetype.startsWith("video/") ? "video" : "image";
        const count = await db
          .select({ n: sql<number>`count(*)::int` })
          .from(propertyMedia)
          .where(eq(propertyMedia.property_id, propertyId));
        const displayOrder = (count[0]?.n ?? 0);
        const [row] = await db
          .insert(propertyMedia)
          .values({
            property_id: propertyId,
            media_url: relativePath,
            media_type: mediaType,
            display_order: displayOrder,
          })
          .returning();
        res.status(201).json(row);
      } catch (e: any) {
        res.status(500).json({ message: e?.message || "Upload failed" });
      }
    }
  );

  app.delete("/api/admin/property-media/:id", requireAdmin, async (req, res) => {
    try {
      await db.delete(propertyMedia).where(eq(propertyMedia.id, req.params.id));
      res.status(204).send();
    } catch (e: any) {
      res.status(500).json({ message: e?.message || "Failed" });
    }
  });

  // ----- Admin: Contact inquiries -----
  app.get("/api/admin/contact-inquiries", requireAdmin, async (req, res) => {
    try {
      const rows = await db
        .select({
          id: contactInquiries.id,
          property_id: contactInquiries.property_id,
          name: contactInquiries.name,
          email: contactInquiries.email,
          phone: contactInquiries.phone,
          message: contactInquiries.message,
          is_read: contactInquiries.is_read,
          created_at: contactInquiries.created_at,
          title: properties.title,
        })
        .from(contactInquiries)
        .leftJoin(properties, eq(contactInquiries.property_id, properties.id))
        .orderBy(desc(contactInquiries.created_at));
      res.json(
        rows.map(({ title, ...r }) => ({ ...r, properties: title ? { title } : null }))
      );
    } catch (e: any) {
      res.status(500).json({ message: e?.message || "Failed" });
    }
  });

  app.patch("/api/admin/contact-inquiries/:id/read", requireAdmin, async (req, res) => {
    try {
      await db
        .update(contactInquiries)
        .set({ is_read: true })
        .where(eq(contactInquiries.id, req.params.id));
      res.json({ message: "ok" });
    } catch (e: any) {
      res.status(500).json({ message: e?.message || "Failed" });
    }
  });

  // ----- Admin: Site settings -----
  app.post("/api/admin/site-settings/upsert", requireAdmin, async (req, res) => {
    try {
      const { key, value } = req.body;
      if (!key) return res.status(400).json({ message: "key required" });
      await db
        .insert(siteSettings)
        .values({ key, value: value ?? null })
        .onConflictDoUpdate({
          target: siteSettings.key,
          set: { value: value ?? null, updated_at: new Date() },
        });
      const [row] = await db.select().from(siteSettings).where(eq(siteSettings.key, key));
      res.json(row);
    } catch (e: any) {
      res.status(500).json({ message: e?.message || "Failed" });
    }
  });

  // ----- Admin: Navbar links -----
  app.get("/api/admin/navbar-links", requireAdmin, async (_req, res) => {
    try {
      const rows = await db.select().from(navbarLinks).orderBy(asc(navbarLinks.display_order));
      res.json(rows);
    } catch (e: any) {
      res.status(500).json({ message: e?.message || "Failed" });
    }
  });

  app.post("/api/admin/navbar-links", requireAdmin, async (req, res) => {
    try {
      const { label, href } = req.body;
      if (!label || !href) return res.status(400).json({ message: "label and href required" });
      const count = await db.select({ n: sql<number>`count(*)::int` }).from(navbarLinks);
      const displayOrder = (count[0]?.n ?? 0) + 1;
      const [row] = await db
        .insert(navbarLinks)
        .values({ label, href, display_order: displayOrder })
        .returning();
      res.status(201).json(row);
    } catch (e: any) {
      res.status(500).json({ message: e?.message || "Failed" });
    }
  });

  app.patch("/api/admin/navbar-links/:id", requireAdmin, async (req, res) => {
    try {
      const body = req.body;
      const [row] = await db
        .update(navbarLinks)
        .set({
          ...(body.label !== undefined && { label: body.label }),
          ...(body.href !== undefined && { href: body.href }),
          ...(body.display_order !== undefined && { display_order: body.display_order }),
          ...(body.is_visible !== undefined && { is_visible: body.is_visible }),
          updated_at: new Date(),
        })
        .where(eq(navbarLinks.id, req.params.id))
        .returning();
      if (!row) return res.status(404).json({ message: "Not found" });
      res.json(row);
    } catch (e: any) {
      res.status(500).json({ message: e?.message || "Failed" });
    }
  });

  app.delete("/api/admin/navbar-links/:id", requireAdmin, async (req, res) => {
    try {
      await db.delete(navbarLinks).where(eq(navbarLinks.id, req.params.id));
      res.status(204).send();
    } catch (e: any) {
      res.status(500).json({ message: e?.message || "Failed" });
    }
  });

  app.post("/api/admin/navbar-links/reorder", requireAdmin, async (req, res) => {
    try {
      const { aId, bId } = req.body;
      if (!aId || !bId) return res.status(400).json({ message: "aId and bId required" });
      const [a, b] = await Promise.all([
        db.select().from(navbarLinks).where(eq(navbarLinks.id, aId)).then((r) => r[0]),
        db.select().from(navbarLinks).where(eq(navbarLinks.id, bId)).then((r) => r[0]),
      ]);
      if (!a || !b) return res.status(404).json({ message: "Link not found" });
      await db.update(navbarLinks).set({ display_order: b.display_order, updated_at: new Date() }).where(eq(navbarLinks.id, aId));
      await db.update(navbarLinks).set({ display_order: a.display_order, updated_at: new Date() }).where(eq(navbarLinks.id, bId));
      res.json({ message: "ok" });
    } catch (e: any) {
      res.status(500).json({ message: e?.message || "Failed" });
    }
  });

  // ----- Admin: Social integrations -----
  app.get("/api/admin/social-integrations", requireAdmin, async (_req, res) => {
    try {
      const rows = await db.select().from(socialIntegrations);
      res.json(rows);
    } catch (e: any) {
      res.status(500).json({ message: e?.message || "Failed" });
    }
  });

  app.put("/api/admin/social-integrations", requireAdmin, async (req, res) => {
    try {
      const { platform, url, is_enabled } = req.body;
      if (!platform) return res.status(400).json({ message: "platform required" });
      await db
        .insert(socialIntegrations)
        .values({ platform, url: url ?? null, is_enabled: is_enabled ?? false })
        .onConflictDoUpdate({
          target: socialIntegrations.platform,
          set: { url: url ?? null, is_enabled: is_enabled ?? false, updated_at: new Date() },
        });
      const [row] = await db.select().from(socialIntegrations).where(eq(socialIntegrations.platform, platform));
      res.json(row);
    } catch (e: any) {
      res.status(500).json({ message: e?.message || "Failed" });
    }
  });

  // 404 for unknown API
  app.use("/api", (_req, res) => {
    res.status(404).json({ message: "Not found" });
  });
}
