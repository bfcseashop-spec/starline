import { db } from "./db";
import { navbarLinks, siteSettings, socialIntegrations } from "../shared/schema";

export async function seedDatabase() {
  const existingNav = await db.select().from(navbarLinks).limit(1);
  if (existingNav.length > 0) return;

  await db.insert(navbarLinks).values([
    { label: "Home", href: "/", display_order: 1, is_visible: true },
    { label: "Properties", href: "/properties", display_order: 2, is_visible: true },
    { label: "Contact", href: "/contact", display_order: 3, is_visible: true },
  ]);

  const defaultSettings = [
    { key: "currency", value: "BDT" },
    { key: "currency_symbol", value: "৳" },
    { key: "phone_bd", value: "+880 170 000 0000" },
    { key: "phone_dubai", value: "+971 4 000 0000" },
    { key: "email", value: "info@skylineholding.com" },
    { key: "address_bd", value: "Gulshan 2, Dhaka 1212, Bangladesh" },
    { key: "address_dubai", value: "Downtown Dubai, UAE" },
    { key: "site_title", value: "Skyline Holding Ltd" },
    { key: "site_tagline", value: "Premium Real Estate in Bangladesh & Dubai" },
  ];
  for (const s of defaultSettings) {
    await db.insert(siteSettings).values(s).onConflictDoNothing({ target: siteSettings.key });
  }

  const platforms = ["youtube", "facebook", "instagram", "tiktok", "twitter", "linkedin", "whatsapp"];
  for (const platform of platforms) {
    await db
      .insert(socialIntegrations)
      .values({ platform, url: "", is_enabled: false })
      .onConflictDoNothing({ target: socialIntegrations.platform });
  }

  console.log("Seed completed.");
}
