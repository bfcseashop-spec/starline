import {
  pgTable,
  text,
  varchar,
  integer,
  numeric,
  boolean,
  timestamp,
  uuid,
  jsonb,
} from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";

// App role enum equivalent (stored as text with check in DB)
export const appRoleEnum = ["admin", "user"] as const;
export type AppRole = (typeof appRoleEnum)[number];

// Users (replaces Supabase auth.users for login)
export const users = pgTable("users", {
  id: uuid("id").primaryKey().defaultRandom(),
  email: text("email").notNull().unique(),
  password: text("password").notNull(),
  full_name: text("full_name"),
  created_at: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updated_at: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
});

// User roles (user_id references our users table)
export const userRoles = pgTable("user_roles", {
  id: uuid("id").primaryKey().defaultRandom(),
  user_id: uuid("user_id").references(() => users.id, { onDelete: "cascade" }).notNull(),
  role: text("role").notNull(), // 'admin' | 'user'
});

// Properties
export const properties = pgTable("properties", {
  id: uuid("id").primaryKey().defaultRandom(),
  title: text("title").notNull(),
  description: text("description"),
  address: text("address").notNull(),
  city: text("city").notNull().default("Dhaka"),
  country: text("country").notNull().default("Bangladesh"),
  price: numeric("price", { precision: 14, scale: 2 }).notNull(),
  price_type: text("price_type").notNull().default("sale"), // sale | rent
  property_type: text("property_type").notNull().default("apartment"),
  bedrooms: integer("bedrooms"),
  bathrooms: integer("bathrooms"),
  area_sqft: numeric("area_sqft", { precision: 12, scale: 2 }),
  is_featured: boolean("is_featured").default(false),
  status: text("status").notNull().default("available"), // available | sold | rented
  cover_image_url: text("cover_image_url"),
  is_installment: boolean("is_installment").notNull().default(false),
  down_payment_pct: numeric("down_payment_pct", { precision: 5, scale: 2 }).notNull().default("20"),
  installment_years: integer("installment_years").notNull().default(5),
  created_at: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updated_at: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
});

// Property media
export const propertyMedia = pgTable("property_media", {
  id: uuid("id").primaryKey().defaultRandom(),
  property_id: uuid("property_id").references(() => properties.id, { onDelete: "cascade" }).notNull(),
  media_url: text("media_url").notNull(),
  media_type: text("media_type").notNull().default("image"), // image | video
  display_order: integer("display_order").default(0),
  created_at: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

// Contact inquiries
export const contactInquiries = pgTable("contact_inquiries", {
  id: uuid("id").primaryKey().defaultRandom(),
  property_id: uuid("property_id").references(() => properties.id, { onDelete: "set null" }),
  name: text("name").notNull(),
  email: text("email").notNull(),
  phone: text("phone"),
  message: text("message").notNull(),
  is_read: boolean("is_read").default(false),
  created_at: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

// Site settings (key-value)
export const siteSettings = pgTable("site_settings", {
  id: uuid("id").primaryKey().defaultRandom(),
  key: text("key").notNull().unique(),
  value: text("value"),
  created_at: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updated_at: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
});

// Navbar links
export const navbarLinks = pgTable("navbar_links", {
  id: uuid("id").primaryKey().defaultRandom(),
  label: text("label").notNull(),
  href: text("href").notNull(),
  display_order: integer("display_order").notNull().default(0),
  is_visible: boolean("is_visible").notNull().default(true),
  created_at: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updated_at: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
});

// Social integrations
export const socialIntegrations = pgTable("social_integrations", {
  id: uuid("id").primaryKey().defaultRandom(),
  platform: text("platform").notNull().unique(),
  url: text("url"),
  is_enabled: boolean("is_enabled").notNull().default(false),
  created_at: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updated_at: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
});

// Session table for connect-pg-simple (so drizzle-kit push doesn't drop it)
export const session = pgTable("session", {
  sid: varchar("sid", { length: 255 }).primaryKey(),
  sess: jsonb("sess").notNull(),
  expire: timestamp("expire", { withTimezone: true }).notNull(),
});

// Relations
export const userRolesRelations = relations(userRoles, ({ one }) => ({
  user: one(users),
}));

export const propertiesRelations = relations(properties, ({ many }) => ({
  media: many(propertyMedia),
  contactInquiries: many(contactInquiries),
}));

export const propertyMediaRelations = relations(propertyMedia, ({ one }) => ({
  property: one(properties),
}));

export const contactInquiriesRelations = relations(contactInquiries, ({ one }) => ({
  property: one(properties),
}));
