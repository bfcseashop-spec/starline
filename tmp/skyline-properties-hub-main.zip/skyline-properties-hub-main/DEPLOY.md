# Skyline Properties Hub – Deploy (PostgreSQL, PM2)

Same pattern as primepos: backup, pull, build, db push, PM2 restart.

## Server setup

1. **PostgreSQL**: Create DB and user, e.g.:
   - `createuser -P skyline_user`
   - `createdb -O skyline_user skyline_db`

2. **.env** (copy from `.env.example`):
   - `DATABASE_URL=postgresql://skyline_user:PASSWORD@localhost:5432/skyline_db`
   - `PORT=5011`
   - `SESSION_SECRET=<long random string>` (keep unchanged so sessions survive deploys)

3. **First deploy**:
   - Clone repo, `cd skyline-properties-hub`
   - `cp .env.example .env` and edit
   - `npm install`
   - `npm run db:push` (creates tables)
   - `npm run create:super-admin` (creates admin: admin@skylineholding.com / SkylineAdmin2233@@)
   - `npm run build`
   - `pm2 start ecosystem.config.cjs` (or `npm run pm2:restart`)

4. **Later deploys**:
   - `cd /var/www/skyline-properties-hub && git pull && bash deploy.sh`

Backups: code → `backups/MM-DD-YYYY-HH-MM-skyline.tar.gz`, DB → `backups/MM-DD-YYYY-HH-MM-skyline.sql`.
