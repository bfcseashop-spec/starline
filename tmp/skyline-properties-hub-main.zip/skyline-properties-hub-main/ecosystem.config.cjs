// PM2 config for Skyline Properties Hub.
// First time: pm2 start ecosystem.config.cjs
// Deploy: bash deploy.sh (or npm run deploy)
// Ensure .env has DATABASE_URL, PORT, SESSION_SECRET.

module.exports = {
  apps: [
    {
      name: "skyline",
      script: "start.cjs",
      cwd: __dirname,
      env: { NODE_ENV: "production", PORT: "5011" },
      env_file: ".env",
      instances: 1,
      autorestart: true,
      max_restarts: 10,
      min_uptime: "10s",
    },
  ],
};
