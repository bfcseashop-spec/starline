import { build as esbuild } from "esbuild";
import { build as viteBuild } from "vite";
import { rm, readFile, copyFile } from "fs/promises";
import path from "path";

const allowlist = [
  "bcryptjs",
  "connect-pg-simple",
  "dotenv",
  "drizzle-orm",
  "express",
  "express-session",
  "multer",
  "pg",
];

async function buildAll() {
  await rm("dist", { recursive: true, force: true });

  console.log("building client...");
  await viteBuild();

  console.log("building server...");
  const pkg = JSON.parse(await readFile("package.json", "utf-8"));
  const allDeps = [
    ...Object.keys(pkg.dependencies || {}),
    ...Object.keys(pkg.devDependencies || {}),
  ];
  const externals = allDeps.filter((d) => !allowlist.includes(d));

  await esbuild({
    entryPoints: ["server/index.ts"],
    platform: "node",
    bundle: true,
    format: "cjs",
    outfile: "dist/index.cjs",
    define: { "process.env.NODE_ENV": '"production"' },
    minify: true,
    external: externals,
    logLevel: "info",
  });

  await copyFile(
    path.join(process.cwd(), "node_modules/connect-pg-simple/table.sql"),
    path.join(process.cwd(), "dist/table.sql")
  );
}

buildAll().catch((err) => {
  console.error(err);
  process.exit(1);
});
