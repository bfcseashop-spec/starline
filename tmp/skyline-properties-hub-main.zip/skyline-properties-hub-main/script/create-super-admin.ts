import "dotenv/config";
import bcrypt from "bcryptjs";
import { db } from "../server/db";
import { users, userRoles } from "../shared/schema";
import { eq } from "drizzle-orm";

const ADMIN_EMAIL = "admin@skylineholding.com";
const ADMIN_PASSWORD = "SkylineAdmin2233@@";

async function main() {
  if (!process.env.DATABASE_URL) {
    console.error("DATABASE_URL is not set in .env");
    process.exit(1);
  }

  const [existing] = await db.select().from(users).where(eq(users.email, ADMIN_EMAIL));
  let userId: string;

  if (existing) {
    userId = existing.id;
    const hash = await bcrypt.hash(ADMIN_PASSWORD, 10);
    await db.update(users).set({ password: hash, updated_at: new Date() }).where(eq(users.id, userId));
    console.log("Updated existing admin password.");
  } else {
    const hash = await bcrypt.hash(ADMIN_PASSWORD, 10);
    const [inserted] = await db
      .insert(users)
      .values({ email: ADMIN_EMAIL, password: hash, full_name: "Super Admin" })
      .returning();
    if (!inserted) throw new Error("Insert failed");
    userId = inserted.id;
    console.log("Created super admin user.");
  }

  const [roleRow] = await db
    .select()
    .from(userRoles)
    .where(eq(userRoles.user_id, userId));
  if (!roleRow) {
    await db.insert(userRoles).values({ user_id: userId, role: "admin" });
    console.log("Assigned admin role.");
  }

  console.log(`Done. Login with email: ${ADMIN_EMAIL}`);
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
